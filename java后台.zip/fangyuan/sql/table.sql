#房源模块表
#例如 租金模块、位置模块、户型模块、面积模块、带扩展模块
DROP TABLE IF EXISTS f_fangzidetail;
create table f_fangzidetail(
fId int primary key AUTO_INCREMENT,
fModularName varchar(50) not null,
value       VARCHAR(100)     NOT NULL ,
pId int , #模块分类id
delFlag int not null
);

DROP TABLE IF EXISTS f_fangyuan;
#房源信息表
#查询筛选条件:价格、时间、户型、面积、位置
create table f_fangyuan(
fyId int primary key AUTO_INCREMENT,
fyDetail varchar(200) null,
fyName varchar(100),
fyaddress varchar(100),
fyMianji double,
fyHuxing varchar(20),
fyZujin double ,
fyTel varchar(11),
fyPrice double,
fyTime datetime not null
);

/**请求日志表*/
DROP TABLE IF EXISTS t_request_log;
CREATE TABLE t_request_log (
  id         BIGINT PRIMARY KEY AUTO_INCREMENT,
  openId     VARCHAR(32)   NULL,
  name       VARCHAR(20)   NULL,
  address    VARCHAR(1000) NOT NULL,
  parameter  VARCHAR(500)  NULL,
  method     VARCHAR(10)   NOT NULL,
  ip         VARCHAR(30)   NOT NULL,
  createTime DATETIME      NOT NULL
);

/**错误代码表*/
DROP TABLE IF EXISTS t_error_code;
create table t_error_code
(
  id			int				primary key AUTO_INCREMENT ,
  code		int				not null,
  reason		varchar(400)	not null,
  description	varchar(200)	null
);

/**系统参数表*/
DROP TABLE IF EXISTS t_system_param;
create table t_system_param
(
  id             INT           PRIMARY KEY AUTO_INCREMENT,
  name           VARCHAR(50)   NOT NULL,
  value          VARCHAR(100)  NOT NULL,
  description    VARCHAR(200)  NULL
);

/**房源大分类*/
DROP TABLE IF EXISTS t_fangyuan_max;
CREATE TABLE t_fangyuan_max
(
  id           INT                          PRIMARY KEY AUTO_INCREMENT,
  title        VARCHAR(200)       NOT NULL #名称
);

/**房源小分类*/
DROP TABLE IF EXISTS t_fangyuan_min;
CREATE TABLE t_fangyuan_min
(
  id                        INT                       PRIMARY KEY AUTO_INCREMENT,
  maxId                 INT                       NOT NULL ,#一级分类Id
  minTitle             VARCHAR(200)   NOT NULL ,#名称
  money                DOUBLE              NULL, #打赏金额
  uploadMoney    DOUBLE              null
);

/**房源其他信息*/
drop table if exists f_fangyuan_eight;
create table f_fangyuan_eight
(
  id                int                   primary key auto_increment,
  maxId            int                   not null ,#一级分类
  minId            int                   not null ,#二级分类
  title             varchar(200)   null , #标题,可以为空
  content       varchar(200)   not null,#内容
  phone         varchar(20)      not null, #手机
  time            timestamp      not null
);

#############群报名##############
/**报名-用户表*/
DROP TABLE IF EXISTS t_bm_user;
CREATE TABLE t_bm_user
(
  openId                VARCHAR(32)                     PRIMARY KEY ,
  nickName            VARCHAR(40)                     NOT NULL ,
  touxiang              VARCHAR(100)                    NOT NULL ,
  createTime          DATETIME                            NOT NULL
);

/**报名-活动表*/
DROP TABLE IF EXISTS t_bm_active;
CREATE TABLE t_bm_active
(
  activeId                INT(6)                                 PRIMARY KEY AUTO_INCREMENT,
  title                      VARCHAR(30)                      NOT NULL ,#标题
  template              VARCHAR(100)                    NULL,#模板地址
  content                VARCHAR(1000)                  NOT NULL ,#内容
  img_one               VARCHAR(200)                    NULL,
  img_two               VARCHAR(200)                    NULL,
  img_three             VARCHAR(200)                    NULL,
  img_four             VARCHAR(200)                    NULL,
  img_five             VARCHAR(200)                    NULL,
  img_six            VARCHAR(200)                    NULL,
  img_seven       varchar(200)                         null,
  img_eight             VARCHAR(200)                    NULL,
  img_neight             VARCHAR(200)                    NULL,
  isPay                     int(1)                                    NOT NULL ,#是否付费
  money                  DOUBLE                               NULL ,#报名费
  leaderId               varchar (32)                          not null ,
  leader                   VARCHAR(40)                      NOT NULL ,#发起人
  address                 VARCHAR(100)                    NULL,#活动地址
  latitude                   varchar (30)                        null ,
  longitude                varchar (30)                         null,
  limitOfNumber    INT(4)                                   NULL ,#人数限制
  fileNumber            INT(10)                   NULL ,#文号
  forward                  INT(1)                                  NOT NULL ,#是否禁止转发
  cell_req            INT(1)                                  NOT NULL ,#是否需要报名者填写手机号
  cell_name             INT(1)                                  NOT NULL #是否需要报名者填写姓名
);

/**报名-报名表*/
DROP TABLE IF EXISTS t_bm_baoming;
CREATE TABLE t_bm_baoming
(
  openId                   VARCHAR(30)                     NOT NULL ,
  activeId                  INT(6)                                  NOT NULL ,
  userName              VARCHAR(40)                     NULL ,
  touxiang                VARCHAR(150)                    NULL ,
  phone                     VARCHAR(150)                   NULL ,
  joinTime                 DATETIME                          NOT NULL ,
  PRIMARY KEY (openId,activeId)
);

/**报名-留言表*/
DROP TABLE IF EXISTS t_bm_liuyan;
CREATE TABLE t_bm_liuyan
(
  lyId                         INT(5)                                 PRIMARY KEY AUTO_INCREMENT,
  activeId                  INT(6)                                 NOT NULL ,
  openId                   VARCHAR(32)                     NOT NULL ,
  nickName               VARCHAR(100)                   NOT NULL ,
  touxiang                VARCHAR(200)                   NOT NULL ,
  content                  VARCHAR(200)                   NOT NULL ,
  createTime             DATETIME                           NOT NULL
);

/**报名-回复表*/
drop TABLE IF EXISTS t_bm_huifu;
create TABLE t_bm_huifu
(
  hfId                       int(5)                                     primary key auto_increment,
  lyId                        int(5)                                     not null ,
  activeId                 int(6)                                     not null ,
  openId                   VARCHAR(32)                     NOT NULL ,
  nickName               VARCHAR(100)                   NOT NULL ,
  touxiang                VARCHAR(200)                   NOT NULL ,
  target                     VARCHAR (50)                    NULL , #目标人
  content                  VARCHAR(200)                   NOT NULL ,
  createTime             DATETIME                           NOT NULL
);

/**看过的人*/
DROP TABLE IF EXISTS t_bm_lookactive;
CREATE TABLE t_bm_lookactive
(
  id                          INT(8)                                    PRIMARY KEY AUTO_INCREMENT,
  openId                  VARCHAR(30)                       NOT NULL ,
  touxiang               VARCHAR(200)                     NOT NULL ,
  activeId                 INT(6)                                    NOT NULL
);