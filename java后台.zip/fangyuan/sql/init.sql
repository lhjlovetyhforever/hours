﻿
insert into t_system_param(name, value, description)
values('TOKEN_KEY', '123456', '消息鉴权机制生成token的MD5秘钥');
insert into t_system_param(name, value, description)
values('TOKEN_VALID_TIME', '600', 'token有效时间限制600秒');
insert into t_system_param(name, value, description)
values('DES_KEY_WORD', '12345678', 'des加密参数');
insert into t_system_param(name, value, description)
values('QUERY_DAYS_MAX', '60', '按时间范围查询的最大天数');
insert into t_system_param(name, value, description)
values('PAGE_MAX_SIZE', '50', '分页查询时一页数据的最大条数');

insert into t_error_code(code, reason, description)
values(200, '操作成功', '操作成功');
insert into t_error_code(code, reason, description)
values(400, '参数错误', '错误参数');
insert into t_error_code(code, reason, description)
values(401, '需要鉴权', '错误参数');
insert into t_error_code(code, reason, description)
values(404, '未查询到结果', '错误参数');
insert into t_error_code(code, reason, description)
values(408, '重复操作', '错误参数');
insert into t_error_code(code, reason, description)
values(500, '系统错误', '错误参数');
