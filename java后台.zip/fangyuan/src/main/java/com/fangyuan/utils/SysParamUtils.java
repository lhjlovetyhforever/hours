package com.fangyuan.utils;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * 定义获取系统参数的属性
 * @author ll
 *
 */
public class SysParamUtils {

    public static String BASE_URL = "https://haijiyungui.com/";
    /**用于获取计算token的密钥**/
    public static String TOKEN_KEY = "123456";
    /**用于获取token的有效时间**/
    public static String TOKEN_VALID_TIME = "600";
    /**DES加密秘钥**/
    public static String DES_KEY_WORD = "12345678";
    /**按时间范围查询的最大天数*/
    public static String QUERY_DAYS_MAX = "60";
    /**分页查询时一页数据的最大条数*/
    public static int PAGE_MAX_SIZE = 20;
    public static String DEFAULT_GENEALOGY_TYPE = "1";
    public static String DEFAULT_GENEALOGY_MAP_TYPE = "1";
    public static String DEFAULT_MEMBER_ROLE = "1";
    public static String DEFAULT_GENEALOGY_ROLE = "2";
    public static String DEFAULT_USER_RANK = "1";
    public static String DEFAULT_GENEALOGY_MAP_STATUS = "1";
    public static String MONEY_TO_COIN = "1";
    public static String COIN_TO_POINT = "100";

    public static final String PROCESS_RUN = "run";
    public static final String PROCESS_DEBUG = "debug";

    public static String Process = null;

    private static Map<String, String> paramsMap = new HashMap<>();

    public static void initSystemParams(WebApplicationContext context){

        SessionFactory sessionFactory = (SessionFactory) context.getBean("sessionFactory");

        Session session = sessionFactory.openSession();

        String sql = "select name,value from t_system_param";
        Query query = session.createSQLQuery(sql);
        ArrayList<Object> data = (ArrayList<Object>) query.list();
        session.flush();
        for (Iterator iterator = data.iterator();iterator.hasNext();) {
            Object[] objects = (Object[]) iterator.next();
            paramsMap.put(objects[0].toString().toUpperCase(),(String)objects[1]);
        }
        getSystemParams();
        session.close();

        Process = context.getServletContext().getInitParameter("process");
    }

    public static void getSystemParams(){
        TOKEN_KEY = paramsMap.get("TOKEN_KEY");
        TOKEN_VALID_TIME = paramsMap.get("TOKEN_VALID_TIME");
        DES_KEY_WORD = paramsMap.get("DES_KEY_WORD");
        QUERY_DAYS_MAX = paramsMap.get("QUERY_DAYS_MAX");
        PAGE_MAX_SIZE = Integer.parseInt(paramsMap.get("PAGE_MAX_SIZE"));
        DEFAULT_GENEALOGY_TYPE = paramsMap.get("DEFAULT_GENEALOGY_TYPE");
        DEFAULT_GENEALOGY_MAP_TYPE = paramsMap.get("DEFAULT_GENEALOGY_MAP_TYPE");
        DEFAULT_MEMBER_ROLE = paramsMap.get("DEFAULT_MEMBER_ROLE");
        DEFAULT_GENEALOGY_ROLE = paramsMap.get("DEFAULT_GENEALOGY_ROLE");
        DEFAULT_USER_RANK = paramsMap.get("DEFAULT_USER_RANK");
        DEFAULT_GENEALOGY_MAP_STATUS = paramsMap.get("DEFAULT_GENEALOGY_MAP_STATUS");
        MONEY_TO_COIN = paramsMap.get("MONEY_TO_COIN");
        COIN_TO_POINT = paramsMap.get("COIN_TO_POINT");
        paramsMap.clear();
    }
}
