package com.fangyuan.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
    public static final String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss (Z)";

    /**初始化日期格式**/
    private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat(DEFAULT_PATTERN);

    public static final int SECONDS_OF_DAY = 86400;

    /**
     * 将字符串转换为Date类型的日期
     * @param format
     * @param timestamp
     * @return
     * @throws ParseException
     */
    public static Date parseStrDate(String format, String timestamp) throws ParseException{
        if(format != null){
            SIMPLE_DATE_FORMAT.applyPattern(format);
        }else{
            SIMPLE_DATE_FORMAT.applyPattern(DEFAULT_PATTERN);
        }
        return SIMPLE_DATE_FORMAT.parse(timestamp);
    }

    /**
     * 将Date 转换为指定格式的日期
     * @param format
     * @param dt
     * @return
     */
    public static String formatDate(String format, Date dt){
        synchronized(dt){
            if(format != null){
                SIMPLE_DATE_FORMAT.applyPattern(format);
            }else{
                SIMPLE_DATE_FORMAT.applyPattern(DEFAULT_PATTERN);
            }
            return SIMPLE_DATE_FORMAT.format(dt);
        }
    }

    public static synchronized Date getDate(){
        return new Date();
    }

    public static long getIntervalSeconds(Date d1, Date d2){
        return (d1.getTime() - d2.getTime()) / 1000;
    }
}
