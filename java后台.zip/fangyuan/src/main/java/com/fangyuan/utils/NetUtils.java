package com.fangyuan.utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NetUtils {

    private static Logger logger = Logger.getLogger(NetUtils.class);

    public static String getHttpRequestBody(HttpServletRequest request){

        Object requestContext = request.getAttribute("requestContext");
        if(requestContext != null){
            return requestContext.toString();
        }
        String result = null;
        try {
            request.setCharacterEncoding("UTF-8");

            int contentLen = request.getContentLength();
            if(contentLen > 0){
                InputStream is = request.getInputStream();
                byte[] message = new byte[contentLen];
                int readLen = 0;
                int readLengthThisTime = 0;
                while (readLen != contentLen) {
                    readLengthThisTime = is.read(message, readLen, contentLen - readLen);
                    if (readLengthThisTime == -1){
                        break;
                    }
                    readLen += readLengthThisTime;
                }
                if(readLen >= contentLen){
                    result = new String(message, "UTF-8");
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return null;
        }
        logger.info("request 信息：" + result);
        request.setAttribute("requestContext", result);
        return result;
    }

    public static String getToken(){
        String result = "";
        BufferedReader in ;
        try {
            String urlNameString = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx7ce501e4e0097a24&secret=86bfa3d9a781bed13a25c5e001791ab4";
            URL realUrl = new URL(urlNameString);
            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Content-type", "application/json; charset=utf-8");

            // 建立实际的连接
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : map.keySet()) {
                System.out.println(key + "--->" + map.get(key));
            }
            String line ;
            // 定义 BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(
                    connection.getInputStream()));
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送GET请求出现异常！" + e);
            e.printStackTrace();
        }
        return result;
    }



    public static void main(String agr[]){
        Map map = getminiqrQr(JSONObject.parseObject(getToken()).getString("access_token"));
        System.out.println(map);
    }

    public void getTaiyangma(String token,String param){
        String s = sendPost("https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + token, param);
        System.out.println(s);
    }

    public static Map getminiqrQr(String accessToken) {
        RestTemplate rest = new RestTemplate();
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            //获取小程序二维码
            String url = "https://api.weixin.qq.com/cgi-bin/wxaapp/createwxaqrcode?access_token="+accessToken;
            Map<String,Object> param = new HashMap<>();
            param.put("width",430);
            param.put("path", "pages/index/index?scene=xiaomao");
//            LOG.info("调用生成微信URL接口传参:" + param);
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            HttpEntity requestEntity = new HttpEntity(param, headers);
            ResponseEntity<byte[]> entity = rest.exchange(url, HttpMethod.POST, requestEntity, byte[].class, new Object[0]);
//            LOG.info("调用小程序生成微信永久小程序码URL接口返回结果:" + entity.getBody());
            byte[] result = entity.getBody();
            inputStream = new ByteArrayInputStream(result);

            File file = new File("F:/xiaomao.png");
            if (!file.exists()){
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            int len = 0;
            byte[] buf = new byte[1024];
            while ((len = inputStream.read(buf, 0, 1024)) != -1) {
                outputStream.write(buf, 0, len);
            }
            outputStream.flush();
        } catch (Exception e) {
//            LOG.error("调用小程序生成微信永久小程序码URL接口异常",e);
        } finally {
            if(inputStream != null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(outputStream != null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public static String sendPost(String URL,String data){
        byte[] xmlData = data.getBytes();
        InputStream instr = null;
        try {
            URL url = new URL(URL);
            logger.info(url);
            URLConnection urlCon = url.openConnection();
            urlCon.setDoOutput(true);
            logger.info(data);
            urlCon.setDoInput(true);
            urlCon.setUseCaches(false);
            // 发送POST请求必须设置如下两行
            urlCon.setDoOutput(true);
            DataOutputStream printout = new DataOutputStream(
                    urlCon.getOutputStream());
            printout.write(xmlData);
            printout.close();
            printout.flush();
            instr = urlCon.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(instr));
            StringBuilder json = new StringBuilder();
            String a ;
            while ((a = in.readLine()) != null) {
                json.append(a);
            }
            System.out.println("返回数据为:" + json);
            return json.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        } finally {
            try {
                assert instr != null;
                instr.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
