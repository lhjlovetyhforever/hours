package com.fangyuan.utils;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.json.JSONObject;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataUtils {

    private static Logger logger = Logger.getLogger(DataUtils.class);
    private static ObjectMapper objectMapper = new ObjectMapper();
    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    private static Pattern P = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");


    static{
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        objectMapper.setSerializationInclusion(Include.NON_NULL);
        objectMapper.setDateFormat(new SimpleDateFormat(DateUtils.DEFAULT_PATTERN));
    }
    /**
     * MD5 16位加密
     *
     * @param string
     * @return
     */
    public static String MD5(String string) {
        String result = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(string.getBytes());
            byte b[] = md.digest();
            int i;
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0){
                    i += 256;
                }
                if (i < 16){
                    buf.append("0");
                }
                buf.append(Integer.toHexString(i));
            }
            result = buf.toString().substring(8, 24);
//			System.out.println("mdt 16bit: " + buf.toString().substring(8, 24));
//			System.out.println("md5 32bit: " + buf.toString());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return result;
    }

    public static String UTF8String(String string) {
        if (string == null) {
            string = "";
        }
        try {
            string = new String(string.getBytes("ISO8859_1"), "UTF-8");
            return string;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return string;
    }

    public static boolean isMobileNumber(String mobiles) {
        Matcher m = P.matcher(mobiles);
        return m.matches();
    }

    public static boolean isChinese(char a) {
        int v = (int) a;
        return (v >= 19968 && v <= 171941);
    }

    public static boolean isEqual(Number n1, Number n2){
        if(n1.equals(n2)){
            return true;
        }
        if(n1 != null && n2 != null){
            return n1.longValue() == n2.longValue();
        }
        return false;
    }

    /**
     * 判断字符是否含有中文
     * @param s
     * @return
     */
    public static boolean containsChinese(String s) {
        if (null == s || "".equals(s.trim())){
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            if (isChinese(s.charAt(i))){
                return true;
            }
        }
        return false;
    }


    public static byte[] encrypt(byte[] src, byte[] key, boolean encrypt) throws Exception {
        // DES算法要求有一个可信任的随机数源
        SecureRandom sr = new SecureRandom();

        // 从原始密匙数据创建DESKeySpec对象
        DESKeySpec dks = new DESKeySpec(key);

        // 创建一个密匙工厂，然后用它把DESKeySpec转换成一个SecretKey对象
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey securekey = keyFactory.generateSecret(dks);

        // Cipher对象实际完成加密操作
        Cipher cipher = Cipher.getInstance("DES");

        // 用密匙初始化Cipher对象
        if(encrypt){
            cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
        }else{
            cipher.init(Cipher.DECRYPT_MODE, securekey);
        }

        // 执行加密操作
        return cipher.doFinal(src);
    }

    /**
     * Des加密
     * @param str
     * @param key
     * @return
     */
    public final static String encrypt(String str, String key) {

        try {
            return byte2string(encrypt(str.getBytes(), key.getBytes(), true));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return null;
    }

    /**
     * DES 解密
     * @param str
     * @param key
     * @return
     */
    public final static String decrypt(String str, String key) {
        try {
            byte data[] = string2byte(str);
            int i = 0;
            while(i < data.length && data[i] == 0){
                i ++;
            }
            byte bytes[] = Arrays.copyOfRange(data, i, data.length);
            return new String(encrypt(bytes, key.getBytes(), false));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        return null;
    }

    public final static boolean CopyBean(Object src, Object dst){
        try {
            PropertyUtils.copyProperties(dst, src);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
            return false;
        }
        return true;
    }
    public static String Object2JsonString(Object objc){

        String json_string = null;
        try {
            json_string = objectMapper.writeValueAsString(objc);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return json_string;

    }
    public static <T> T Json2Object(String json, Class<T> cls){
        try {
            T obj = (T) objectMapper.readValue(json, cls);
            logger.info("json -> java bean: " + obj);
            Set<ConstraintViolation<T>> constraintViolations = validator.validate(obj);
            for (ConstraintViolation<T> constraintViolation : constraintViolations) {
                logger.warn(String.format("bean 校验失败，对象属性[%s], 错误信息[%s], 错误值[%s]"
                        , constraintViolation.getPropertyPath(), constraintViolation.getMessage()
                        , constraintViolation.getInvalidValue().toString()));
            }
            if(constraintViolations.size() > 0){
                return null;
            }else{
                return obj;
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            logger.error(e.getMessage());
            return null;
        }
    }

    /**
     *
     * @param object
     * @return
     */
    public static HashMap<String, String> json2HashMap(Object object)
    {
        HashMap<String, String> data = new HashMap<String, String>();
        // 将json字符串转换成jsonObject
        JSONObject jsonObject = JSONObject.fromObject(object);
        Iterator it = jsonObject.keys();
        // 遍历jsonObject数据，添加到Map对象
        while (it.hasNext())
        {
            String key = String.valueOf(it.next());
            String value = jsonObject.get(key).toString();
            data.put(key, value);
        }
        return data;
    }

    public static <T> ArrayList<T> Json2Array(String json, Class<T> cls){
        ArrayList<T> rest = new ArrayList<>();
        try {
            BeanInfo bi = Introspector.getBeanInfo(cls);
            PropertyDescriptor pds[] = bi.getPropertyDescriptors();
            ArrayList<LinkedHashMap<String, Object>> list = (ArrayList<LinkedHashMap<String, Object>>) objectMapper.readValue(json, ArrayList.class);

            for (LinkedHashMap<String, Object> e : list) {
                T element = cls.newInstance();
                for(PropertyDescriptor pd : pds){
                    if(e.containsKey(pd.getName())){
                        pd.getWriteMethod().invoke(element, e.get(pd.getName()));
                    }
                }
                rest.add(element);
            }
        } catch (Exception e) {
            // TODO: handle exception
            logger.error(e.getMessage());
            return null;
        }
        return rest;
    }

    private static String byte2string(byte[] b) {
        BigInteger bi = new BigInteger(1, b);
        return bi.toString(16).toLowerCase();
    }

    private static byte[] string2byte(String s){
        BigInteger bi = new BigInteger(s, 16);
        return bi.toByteArray();
    }

    public static String map2Str(Map<String, Object> map) {
        String mapStr = "";
        StringBuilder sb = new StringBuilder();
        if (!map.isEmpty()) {
            sb.append("{");
            for (Entry<String, Object> entry : map.entrySet()) {
                sb.append("\"").append(entry.getKey()).append("\":");
                Object value = entry.getValue();
                if (value instanceof String) {
                    sb.append("\"").append(value).append("\",");
                } else {
                    sb.append(value).append(",");
                }
            }
            mapStr = sb.substring(0, sb.length() - 1) + "}";
        }
        return mapStr;
    }

}
