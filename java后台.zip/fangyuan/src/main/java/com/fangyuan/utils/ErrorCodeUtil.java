package com.fangyuan.utils;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ErrorCodeUtil {

    /**成功*/
    public static final int ERROR_SUCCESS = 200;
    /**参数错误*/
    public static final int ERROR_REQUEST_PARAMETER = 400;
    /**需要鉴权**/
    public static final int ERROR_UNAUTHORIZED = 401;
    /**未查询到结果*/
    public static final int ERROR_NOT_EXIST = 404;
    /**帐号错误*/
    public static final int ERROR_ACCOUNT = 405;
    /**重复操作*/
    public static final int ERROR_REPEAT = 408;
    /**文件为空*/
    public static final int ERROR_NULL_FILE = 440;
    /**保存的照片超过上限*/
    public static final int ERROR_UPPER_LIMIT = 450;
    /**系统错误*/
    public static final int ERROR_SYSTEM = 500;
    /**挑战机会已用完*/
    public static final int ERROR_USE_OUT = 441;
    /**券不足*/
    public static final int LACK_OF_VOUCHER = 442;




    private static final Map<Integer, String> ERROR_CODE_MAP = new HashMap<>();

    public static void initSysErrorCode(ApplicationContext context){
        SessionFactory sessionFactory = (SessionFactory) context.getBean("sessionFactory");
        Session session = sessionFactory.openSession();
        String sql = "select code, reason from t_error_code";
        Query query = session.createSQLQuery(sql);
        ArrayList<Object> data = (ArrayList<Object>) query.list();
        session.flush();
        for (Iterator iterator = data.iterator();iterator.hasNext();) {
            Object[] objects = (Object[]) iterator.next();
            ERROR_CODE_MAP.put((Integer)objects[0],(String)objects[1]);
        }
        session.close();
    }

    public static String getErrorCodeReason(int code){
        return ERROR_CODE_MAP.get(code);
    }

}
