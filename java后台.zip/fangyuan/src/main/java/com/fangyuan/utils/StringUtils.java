package com.fangyuan.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.InvalidParameterSpecException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

public class StringUtils {

    private static final Logger logger = Logger.getLogger(StringUtils.class);

    private static String DESkey = "fupay_18";

    //小程序的APPID
    public final static String APPID = "wx7ce501e4e0097a24";
    //小程序的appsecret
    public final static   String APPSECRET = "86bfa3d9a781bed13a25c5e001791ab4";
    //授权（必填）
    public final static String grant_type = "authorization_code";
    // 算法名称
    static  final String KEY_ALGORITHM = "AES";
    // 加解密算法/模式/填充方式
    static  final String algorithmStr = "AES/CBC/PKCS7Padding";

    /**
     * 判断是否为数字
     * @param str 传入的字符串
     * @return 是整数返回true,否则返回false
     */
    public static boolean isInteger(String str) {
        Pattern pattern = compile("^[-+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }

    /**
     * 加密DES
     * @param string
     * @return
     */
    public static String encryptDESString(String string){
        System.out.println("加密前:"+string);
        if (string!=null && string.length()>0){
            String ens = DataUtils.encrypt(string,DESkey);
            System.out.println("加密后:"+ens);
            System.out.println("转码后:");
            return ens;
        }
        return null;
    }

    /**
     * 解密DES
     * @param string
     * @return
     */
    public static String decryptDESString(String string){
        if (string!=null && string.length()>0){
            return DataUtils.decrypt(string,DESkey);
        }
        return null;
    }

    public static String getOutNetStting(String text) {
        text = getUnicode(text);
        String encod = getEncoding(text);
        System.out.println(text);
        System.out.println(encod);
        text = encryptDESString(text);
        return text;
    }


    /**
     * 将字符串转成unicode
     * @param str 待转字符串
     * @return unicode字符串
     */
    public static String getUnicode(String str)
    {
        str = (str == null ? "" : str);
        String tmp;
        StringBuffer sb = new StringBuffer(1000);
        char c;
        int i, j;
        sb.setLength(0);
        for (i = 0; i < str.length(); i++)
        {
            c = str.charAt(i);
            sb.append("\\u");
            //取出高8位
            j = (c >>>8);
            tmp = Integer.toHexString(j);
            if (tmp.length() == 1){
                sb.append("0");
            }
            sb.append(tmp);
            //取出低8位
            j = (c & 0xFF);
            tmp = Integer.toHexString(j);
            if (tmp.length() == 1){
                sb.append("0");
            }
            sb.append(tmp);
        }
        return (new String(sb));
    }
    public static String getEncoding(String str) {
        String encode = "GB2312";
        try {
            //判断是不是GB2312
            if (str.equals(new String(str.getBytes(encode), encode))) {
                String s = encode;
                //是的话，返回“GB2312“，以下代码同理
                return s;
            }
        } catch (Exception exception) {
        }
        encode = "ISO-8859-1";
        try {
            //判断是不是ISO-8859-1
            if (str.equals(new String(str.getBytes(encode), encode))) {
                String s1 = encode;
                return s1;
            }
        } catch (Exception exception1) {
        }
        encode = "UTF-8";
        try {
            //判断是不是UTF-8
            if (str.equals(new String(str.getBytes(encode), encode))) {
                String s2 = encode;
                return s2;
            }
        } catch (Exception exception2) {
        }
        encode = "GBK";
        try {
            //判断是不是GBK
            if (str.equals(new String(str.getBytes(encode), encode))) {
                String s3 = encode;
                return s3;
            }
        } catch (Exception exception3) {
        }
        //如果都不是，说明输入的内容不属于常见的编码格式。
        return "";
    }

    public static String getUTF8String(String text) {
        // A StringBuffer Object
        StringBuffer sb = new StringBuffer();
        sb.append(text);
        String xmString = "";
        String xmlUTF8="";
        try {
            xmString = new String(sb.toString().getBytes("UTF-8"));
            xmlUTF8 = URLEncoder.encode(xmString, "UTF-8");
            System.out.println("utf-8 编码：" + xmlUTF8) ;
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // return to String Formed
        return xmlUTF8;
    }

    public static void main(String arg[]){
        String appid= "wx7ce501e4e0097a24";
        String session_key = "KFbLY8tb5yeJoKj33Aoq3Q==";
        String data = "Vc5PNCw7x53QuArMql25IuzlsysFJg7sTcKohPSAojtwjEjhf/8OO2bMIA83b6Zueb+5VrLvp2YHc2QyKoLVQtUX5Uv3MvDm05s2HDkldlIMfBeKY4+PRbrzl4sQsYwQdLKP1AgsGGK17Z9P159mVw==";
        String iv = "FL4JNGekw1ZbDZLWRnmpsg==";
        System.out.println(session_key);
        System.out.println(data);
        System.out.println(iv);
        System.out.println(getUserInfo(data,session_key,iv).toJSONString());
    }

    /**
     * 解密用户敏感数据获取用户信息
     *
     * @author zhy
     * @param sessionKey 数据进行加密签名的密钥
     * @param encryptedData 包括敏感数据在内的完整用户信息的加密数据
     * @param iv 加密算法的初始向量
     * @return
     */
    public static JSONObject getUserInfo(String encryptedData,String sessionKey,String iv){
        // 被加密的数据
        byte[] dataByte = org.codehaus.xfire.util.Base64.decode(encryptedData);
        // 加密秘钥
        byte[] keyByte = org.codehaus.xfire.util.Base64.decode(sessionKey);
        // 偏移量
        byte[] ivByte = org.codehaus.xfire.util.Base64.decode(iv);
        try {
            // 如果密钥不足16位，那么就补足.  这个if 中的内容很重要
            int base = 16;
            if (keyByte.length % base != 0) {
                int groups = keyByte.length / base + (keyByte.length % base != 0 ? 1 : 0);
                byte[] temp = new byte[groups * base];
                Arrays.fill(temp, (byte) 0);
                System.arraycopy(keyByte, 0, temp, 0, keyByte.length);
                keyByte = temp;
            }
            // 初始化
            Security.addProvider(new BouncyCastleProvider());
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding","BC");
            SecretKeySpec spec = new SecretKeySpec(keyByte, "AES");
            AlgorithmParameters parameters = AlgorithmParameters.getInstance("AES");
            parameters.init(new IvParameterSpec(ivByte));
            // 初始化
            cipher.init(Cipher.DECRYPT_MODE, spec, parameters);
            byte[] resultByte = null;
            try{
                resultByte = cipher.doFinal(dataByte);
            }catch (Exception e){
                e.printStackTrace();
            }
            if (null != resultByte && resultByte.length > 0) {
                String result = new String(resultByte, "UTF-8");
                return JSON.parseObject(result);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidParameterSpecException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (NoSuchProviderException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 用于将图片文件base64编码返回串
     * @param imgFile  图片文件路径
     * @return base64编码之后的串
     */
    public static String getBase64Str(String imgFile){
        //将图片文件转化为字节数组字符串，并对其进行Base64编码处理
        InputStream in ;
        byte[] data = null;
        //读取图片字节数组
        try{
            in = new FileInputStream(imgFile);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return new String(Objects.requireNonNull(org.apache.commons.codec.binary.Base64.encodeBase64(data)));
    }

    /**
     *   上传图片数据到微软服务器
     *  @param imgPath 要测评的图片路径
     * @return 上传服务器成功后返回的Host，url的json数据
     */
    public static JSONObject Upload(String imgPath){
        String base64Str = getBase64Str(imgPath);
        String result= HttpRequest.sendPost("http://kan.msxiaobing.com/Api/Image/UploadBase64",base64Str);
        return JSONObject.parseObject(result);

    }

    /**
     *   上传图片数据到微软服务器
     *  @param base64 要测评的图片
     * @return 上传服务器成功后返回的Host，url的json数据
     */
    public static JSONObject UploadToBase64(String base64){
        System.out.println("result::::"+base64);
        String result= HttpRequest.sendPost("http://kan.msxiaobing.com/Api/Image/UploadBase64",base64);
        return JSONObject.parseObject(result);

    }

    /**
     * 获取cookies
     * @param u
     */
    public static String getCookies(String u) throws IOException{
        HttpURLConnection conn = null;
        OutputStream os = null;
        InputStream is = null;
        String cookie ="";
        try {
            URL url = new URL(u);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            os = conn.getOutputStream();
            String param = "account=senninha&password=senninha";
            String eparam = param;
            //这里是把post参数携带上去。
            os.write(eparam.getBytes("utf-8"));
            is = conn.getInputStream();
            byte[] b = new byte[1024];
            int len = is.read(b);
            while(len != -1){
                len = is.read(b);
            }
            //这里是读取第一次登陆时服务器返回的cookie，然后用一个全局变量cookie接收。因为是服务器往客户端发送cookie，所以名字是Set-Cookie
//            cookie = conn.getHeaderField("Set-Cookie");
            String cookieVal;
            String key;
            for (int i = 1; (key = conn.getHeaderFieldKey(i)) != null; i++ ) {
                if (key.equalsIgnoreCase("Set-Cookie")) {
                    cookieVal = conn.getHeaderField(i);
                    cookieVal = cookieVal.substring(0, cookieVal.indexOf(";"));
                    cookie=cookie+cookieVal+";";
                }
            }


            System.out.println("read over" + cookie);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }   finally{
            if(os != null){
                os.close();
            }

            if(is != null){
                is.close();
            }
            if(conn != null){
                conn.disconnect();
            }
        }
        return cookie;
    }

    public static JSONObject getScore(String Host, String Url, String cookie,String Ip){
        String map = "MsgId="+System.currentTimeMillis()+"063&"+"CreateTime="+System.currentTimeMillis()+"&Content%5BimageUrl%5D="+Host+""+Url;
        String result= HttpRequest.doHttpPost("http://kan.msxiaobing.com/Api/ImageAnalyze/Process?service=yanzhi&tid=0a4b4e49d9e84d89af61455f5070a00c",map,cookie);
        JSONObject jsonObject= JSONObject.parseObject(result);
        if(jsonObject!=null){
            JSONObject content = (JSONObject) jsonObject.get("content");
            String comments = content.get("text").toString();
            System.out.println("评分结果结果：\n\t"+comments);
            Pattern p = compile("(\\d.\\d分)|(\\d.\\d)");
            Matcher m = p.matcher(comments);
        }else{
            logger.warn("评分异常！！！");
        }
        return jsonObject;
    }

    public static void storecoo(URI uri, String strcoo) {

        // 创建一个默认的 CookieManager

        CookieManager manager = new CookieManager();
        // 将规则改掉，接受所有的 Cookie
        manager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);

        // 保存这个定制的 CookieManager
        CookieHandler.setDefault(manager);

        // 接受 HTTP 请求的时候，得到和保存新的 Cookie
        HttpCookie cookie = new HttpCookie("Cookie: ", strcoo);
        //cookie.setMaxAge(60000);//没这个也行。
        manager.getCookieStore().add(uri, cookie);

    }

    public static HttpCookie getcookies(){

        CookieManager manager = new CookieManager();
        HttpCookie res = null;
        // 使用 Cookie 的时候：
        // 取出 CookieStore
        CookieStore store = manager.getCookieStore();

        // 得到所有的 URI
        List<URI> uris = store.getURIs();
        for (URI ur : uris) {
            // 筛选需要的 URI
            // 得到属于这个 URI 的所有 Cookie
            List<HttpCookie> cookies = store.get(ur);
            for (HttpCookie coo : cookies) {
                res = coo;
            }
        }
        return res;
    }
}
