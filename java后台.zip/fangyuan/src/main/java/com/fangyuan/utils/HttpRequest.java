package com.fangyuan.utils;

import org.apache.log4j.Logger;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class HttpRequest {


    private static Logger logger = Logger.getLogger(HttpRequest.class);
    /**
     * 向指定URL发送GET方法的请求
     *
     * @param url
     *            发送请求的URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return URL 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param) {
        String result = "";
        BufferedReader in = null;
        try {
            String urlNameString = url + "?" + param;
            URL realUrl = new URL(urlNameString);
            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.setRequestProperty("Content-type", "application/json; charset=utf-8");

            Date newdate = new Date();
            SimpleDateFormat formatter;
            formatter = new SimpleDateFormat (DateUtils.DEFAULT_PATTERN);
            String timestamp = formatter.format(newdate);
            String token = DataUtils.MD5(timestamp+"123456");
            connection.setRequestProperty("Timestamp", timestamp);
            connection.setRequestProperty("Auth", token);
            // 建立实际的连接
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : map.keySet()) {
                System.out.println(key + "--->" + map.get(key));
            }
            // 定义 BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(
                    connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送GET请求出现异常！" + e);
            e.printStackTrace();
        }
        // 使用finally块来关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url
     *            发送请求的 URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();

            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0");

            conn.setRequestProperty("Content-type", "application/json; charset=utf-8");
//            SimpleDateFormat formatter;
//            formatter = new SimpleDateFormat (DateUtils.DEFAULT_PATTERN);
//            String timestamp = formatter.format(new Date());
//            String token = DataUtils.MD5(timestamp+"123456");
//            conn.setRequestProperty("Timestamp", timestamp);
//            conn.setRequestProperty("operId","9278");
//            conn.setRequestProperty("Auth", token);
            conn.setRequestProperty("Host","kan.msxiaobing.com");
            conn.setRequestProperty("Origin","http://kan.msxiaobing.com");
            conn.setRequestProperty("Referer","http://kan.msxiaobing.com/V3/Portal?task=yanzhi");
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            out.print(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！"+e);
            e.printStackTrace();
        }
        //使用finally块来关闭输出流、输入流
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result;
    }

    /**
     * 发送Http post请求
     *
     * @param xmlInfo
     *            json转化成的字符串
     * @param URL
     *            请求url
     * @return 返回信息
     */
    public static String doHttpPost(String URL,String xmlInfo,String cookie) {
        byte[] xmlData = xmlInfo.getBytes();
        InputStream instr = null;
        try {
            URL url = new URL(URL);
            logger.info(url);
            URLConnection urlCon = url.openConnection();
            urlCon.setDoOutput(true);
            logger.info(xmlInfo);
            urlCon.setDoInput(true);
            urlCon.setUseCaches(false);
            urlCon.setRequestProperty("content-Type", "application/x-www-form-urlencoded");
            urlCon.setRequestProperty("charset", "utf-8");
            urlCon.setRequestProperty("Content-length",
                    String.valueOf(xmlData.length));
            urlCon.addRequestProperty("cookie","_ga=GA1.2.1597838376.1504599720;_gid=GA1.2.1466467655.1504599720;" +
                    "ai_user=sp1jt|\""+System.currentTimeMillis()+"" +
                    ";cpid=YDLcMF5LPDFfSlQyfUkvMs9IbjQZMiQ2XTJHMVswUTFPAA;" +
                    "salt=EAA803807C2E9ECD7D786D3FA9516786;" +
                    "ARRAffinity=3dc0ec2b3434a920266e7d4652ca9f67c3f662b5a675f83cf7467278ef043663" +
                    "ai_session=sQna0|1504664570638.64|1504664570638111");
            urlCon.setRequestProperty("Host","kan.msxiaobing.com");
            urlCon.setRequestProperty("Origin","http://kan.msxiaobing.com");
            urlCon.setRequestProperty("Referer","http://kan.msxiaobing.com/V3/Portal");
            urlCon.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36");
            urlCon.setRequestProperty("CLIENT-IP","127.0.0.1");
            urlCon.setRequestProperty("X-FORWARDED-FOR","127.0.0.1");
            // 发送POST请求必须设置如下两行
            urlCon.setDoOutput(true);
//            SimpleDateFormat formatter;
//            formatter = new SimpleDateFormat (DateUtils.DEFAULT_PATTERN);
//            String timestamp = formatter.format(new Date());
//            String token = DataUtils.MD5(timestamp+"123456");
//            urlCon.setRequestProperty("Timestamp", timestamp);
//            urlCon.setRequestProperty("operId","9278");
//            urlCon.setRequestProperty("Auth", token);

            DataOutputStream printout = new DataOutputStream(
                    urlCon.getOutputStream());
            printout.write(xmlData);
            printout.close();
            printout.flush();
            instr = urlCon.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(instr));
            StringBuilder json = new StringBuilder();
            String a ;
            while ((a = in.readLine()) != null) {
                json.append(a);
            }
            System.out.println("返回数据为:" + json);
            return json.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        } finally {
            try {
                assert instr != null;
                instr.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }


}
