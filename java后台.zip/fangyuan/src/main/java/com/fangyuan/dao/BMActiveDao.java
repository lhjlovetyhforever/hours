package com.fangyuan.dao;

import com.fangyuan.entity.BMActive;
import org.springframework.stereotype.Repository;

@Repository
public class BMActiveDao extends BaseDao<BMActive> {
}
