package com.fangyuan.dao;

import org.apache.log4j.Logger;
import org.hibernate.EmptyInterceptor;

public class MultiTableInterceptor extends EmptyInterceptor{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2199737207064368842L;
	
	private static Logger logger = Logger.getLogger(MultiTableInterceptor.class);

//	@Override
//	public String onPrepareStatement(String sql) {
//		ThreadContext tc = ThreadContext.getThreadContext();
//		logger.info("origin sql: " + sql);
//		try {
//			if(tc.dao != null && tc.entity != null){
//				String tableName = tc.dao.getEntityTable(tc.entity);
//				String realTableName = tc.dao.getTargetTableName(tc.entity);
//				if(realTableName != null && realTableName.trim().length() > 0){
//					logger.info(String.format("change table from [%s] to [%s]", tableName, realTableName));
//					return sql.replace(tableName, realTableName);
//				}
//			}
//		} catch (Exception e) {
//			logger.error(e.getMessage());
//			return sql;
//		}
//		return sql;
//	}

}
