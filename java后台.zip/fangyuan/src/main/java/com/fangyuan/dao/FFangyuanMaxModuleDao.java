package com.fangyuan.dao;

import com.fangyuan.entity.FFangyuanMaxModule;
import org.springframework.stereotype.Repository;

@Repository
public class FFangyuanMaxModuleDao extends BaseDao<FFangyuanMaxModule> {
}
