package com.fangyuan.dao;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import javax.servlet.http.HttpServletRequest;

public class ThreadContext {

	private static final ThreadLocal<ThreadContext> LOCAL = new ThreadLocal<>();
	
	private static final Logger logger = Logger.getLogger(ThreadContext.class);
	
	Session session = null;
	
	BaseDao<?> dao = null;
	
	Object entity = null;
	
	String openId = null;
	
	HttpServletRequest request = null;

	public static ThreadContext getThreadContext(){
		ThreadContext context = null;
		try{
			context = LOCAL.get();
			if(context == null){
				logger.info("new TheadLocal");
				context = new ThreadContext();
				LOCAL.set(context);
			}
		}catch(Exception e){
			LOCAL.remove();
			logger.error(e.getMessage());
		}
		return context;
	}
	
	public BaseDao<?> getDao() {
		return dao;
	}

	public void setDao(BaseDao<?> dao) {
		this.dao = dao;
	}

	public Object getEntity() {
		return entity;
	}

	public void setEntity(Object entity) {
		this.entity = entity;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}
}
