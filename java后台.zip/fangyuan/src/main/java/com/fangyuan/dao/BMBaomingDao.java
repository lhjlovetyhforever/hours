package com.fangyuan.dao;

import com.fangyuan.entity.BMBaoming;
import org.springframework.stereotype.Repository;

@Repository
public class BMBaomingDao extends BaseDao<BMBaoming> {
}
