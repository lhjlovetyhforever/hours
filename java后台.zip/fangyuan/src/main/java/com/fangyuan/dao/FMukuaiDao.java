package com.fangyuan.dao;
import com.fangyuan.entity.FFmukuai;
import org.springframework.stereotype.Repository;

@Repository
public class FMukuaiDao extends BaseDao<FFmukuai>{

}
