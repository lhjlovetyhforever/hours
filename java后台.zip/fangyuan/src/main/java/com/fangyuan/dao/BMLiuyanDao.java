package com.fangyuan.dao;

import com.fangyuan.entity.BMLiuyan;
import org.springframework.stereotype.Repository;

@Repository
public class BMLiuyanDao extends BaseDao<BMLiuyan> {
}
