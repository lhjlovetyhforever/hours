package com.fangyuan.dao;

import com.fangyuan.entity.FFangyuanMinModule;
import org.springframework.stereotype.Repository;

@Repository
public class FFangyuanMinModuleDao extends BaseDao<FFangyuanMinModule> {
}
