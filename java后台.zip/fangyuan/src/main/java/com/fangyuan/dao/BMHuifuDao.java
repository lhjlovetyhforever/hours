package com.fangyuan.dao;

import com.fangyuan.entity.BMHuifu;
import org.springframework.stereotype.Repository;

@Repository
public class BMHuifuDao extends BaseDao<BMHuifu> {
}
