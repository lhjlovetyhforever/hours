package com.fangyuan.dao;

import com.fangyuan.entity.BMLookActive;
import org.springframework.stereotype.Repository;

@Repository
public class BMLookActiveDao extends BaseDao<BMLookActive> {
}
