package com.fangyuan.dao;

import com.fangyuan.entity.BMUser;
import org.springframework.stereotype.Repository;

@Repository
public class BMUserDao extends BaseDao<BMUser> {
}
