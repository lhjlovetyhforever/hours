package com.fangyuan.dao;

import com.fangyuan.entity.FFangyuanEight;
import org.springframework.stereotype.Repository;

@Repository
public class FFangyuanEightDao extends BaseDao<FFangyuanEight> {
}
