package com.fangyuan.dao;

import com.fangyuan.entity.FFangyuanConfig;
import org.springframework.stereotype.Repository;

@Repository
public class FFangyuanConfgDao extends BaseDao<FFangyuanConfig>{
}
