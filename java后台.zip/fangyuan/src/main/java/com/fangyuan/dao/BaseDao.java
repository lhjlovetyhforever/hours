package com.fangyuan.dao;

import com.fangyuan.dto.SearchPage;
import com.fangyuan.utils.SysParamUtils;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.io.Serializable;
import java.lang.reflect.*;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;

@SuppressWarnings("unchecked")
@Repository
public abstract class BaseDao<T> {
	private static Logger logger = Logger.getLogger(BaseDao.class);
	
	private Class<T> entityClass;
	private String selectFields = null;
	private HashSet<String> tableFields = null;
	private HashSet<String> embedFields = null;
	private Method fGetCacheKey = null;

	@Autowired
	public SessionFactory sessionFactory;
	@Autowired
	public ComboPooledDataSource dataSource;

	@SuppressWarnings("rawtypes")
	public BaseDao() {
		Type genType = getClass().getGenericSuperclass();
		Type[] params = ((ParameterizedType) genType).getActualTypeArguments();
		entityClass = (Class) params[0];
		try {
			fGetCacheKey = entityClass.getMethod("getCacheKey");
		} catch (Exception e) {
			logger.warn(e.getStackTrace());
		}
	}

	public String getEntityTable(Object entity){
		if(entity == null){
			return null;
		}
		try {
			Table annotation = entity.getClass().getAnnotation(Table.class);
			return annotation.name();
		} catch (Exception e) {
			logger.error(e.getStackTrace());
			return null;
		}
	}
	
	public Session getSession(Object entity) {
		ThreadContext tc = ThreadContext.getThreadContext();
		if(tc.session==null){
			tc.session = sessionFactory.openSession();
			logger.info("获取新的session!!!");
			if(tc.session.isOpen()){
				tc.session.setCacheMode(CacheMode.IGNORE);
			}else{
				tc.session=null;
				logger.warn("尝试重新获取session!!!");
				}
		}
		setTheadContext(entity);
		logger.info(String.format("-------------------------%d",Thread.currentThread().getId()));
		return tc.session;
	}
	
	public void setTheadContext(Object entity){
		ThreadContext tc = ThreadContext.getThreadContext();
		tc.dao = this;
		tc.entity = entity;
	}
	
	/**
	 * 根据id查询记录。
	 * @param entity，对象。
	 * @param id，对象ID。
	 * @return 返回完整对象。
	 */
	public T get(T entity, Serializable id) {
		return get(getSession(entity), entity, id);
	}
	
	public T get(Session session, T entity, Serializable id) {
		try {
			String ck = getEntityKey(entity);
			Cache entityCache = null;
			if(ck != null){
				entityCache = getCache();
				if(entityCache != null){
					Element ce = entityCache.get(ck);
					if(ce != null){
						logger.info(" get cache object!");
						return (T)ce.getObjectValue();
					}
				}
			}				
			
			setTheadContext(entity);
			session.clear();
			entity = (T) session.get(entityClass, id);
			session.flush();
			
			if(entityCache != null && entity != null){
				entityCache.put(new Element(ck, entity));
			}
		} catch (Exception e) {
				this.restSession();
			logger.error(e.getMessage());
			entity = null;
		}
		
		return entity;
	}
	
	/**
	 * 根据id更新记录。
	 * @param entity，完整对象。
	 */
	public boolean update(T entity){
		return update(getSession(entity), entity);
	}
	
	public boolean update(Session session, T entity){
		try {
			String ck = getEntityKey(entity);
			
			setTheadContext(entity);
			session.clear();
			session.update(entity);
			session.flush();
			
			Cache entityCache = getCache();
			if(entityCache != null && ck != null){
				entityCache.put(new Element(ck, entity));
			}
		} catch (Exception e) {
				this.restSession();
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 插入记录。
	 * @param entity，对象，不需要id和createTime。
	 * @return 返回完整对象。
	 */
	public T insert(T entity){
		return insert(getSession(entity), entity);
	}
	
	public T insert(Session session, T entity){
		try {
			String ck = getEntityKey(entity);
			
			setTheadContext(entity);
			session.clear();
			session.save(entity);
			session.flush();
			
			Cache entityCache = getCache();
			if(entityCache != null && ck != null){
				entityCache.put(new Element(ck, entity));
			}
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			entity = null;
		}
		
		return entity;
	}
	
	/**
	 * 根据id删除记录。l
	 * @param entity，对象。
	 */
	public boolean delete(T entity){
		return delete(getSession(entity), entity);
	}
	
	public boolean delete(Session session, T entity){
		try {
			String ck = getEntityKey(entity);
			
			setTheadContext(entity);
			session.clear();
			session.delete(entity);
			session.flush();
			
			Cache entityCache = getCache();
			if(entityCache != null && ck != null){
				entityCache.remove(ck);
			}
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	/**
	 * 按条件找到记录。
	 * @param cond，条件。
	 * @param and，条件关系。
	 * @return 返回对象。
	 */
	public T find(T cond, boolean and){
		return find(getSession(cond), cond, and);
	}
	
	public T find(Session session, T cond, boolean and){
		T data = null;
		try {
			setTheadContext(cond);
			session.clear();
			ArrayList<Field> condFields = new ArrayList<>();
			String hql = CreateSearchSql(cond, and, false, condFields);
			if(hql == null){
				logger.warn("create HQL error");
				return null;
			}
			
			Query query = CreateQueryByEntity(session, cond, hql, condFields, false);
			if(query == null){
				logger.warn("create Query erorr");
				return null;
			}
			data = (T)query.uniqueResult();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			data = null;
		}
		
		return data;
	}
	
	/**
	 * 按条件搜索所有记录。
	 * @param cond，条件。
	 * @param and，条件关系。
	 * @return，对象列表。
	 */
	public ArrayList<T> search(T cond, boolean and, boolean like, ArrayList<String> orderFields, boolean desc, SearchPage page){
		return search(getSession(cond), cond, and, like, orderFields, desc, page);
	}
	
	public ArrayList<T> search(Session session, T cond, boolean and, boolean like, ArrayList<String> orderFields, boolean desc, SearchPage page){
		if(page != null && (page.getPageCount() < 0 || page.getPageNumber() < 0 || page.getPageSize() < 0)){
			logger.warn("parameter is error");
			return null;
		}
		ArrayList<T> data = null;
		try {
			setTheadContext(cond);
			session.clear();
			ArrayList<Field> condFields = new ArrayList<>();
			String hql = CreateSearchSql(cond, and, like, condFields);
			if(hql == null){
				logger.warn("create HQL error");
				return null;
			}
			if(orderFields != null && orderFields.size() > 0){
				String orderBySql = "";
				for(String field : orderFields){
					if(orderBySql.trim().length() > 0){
						orderBySql += ",";
					}
					orderBySql += String.format(" t.%s %s", field, desc ? " desc" : "asc");
				}
				hql += String.format(" order by %s", orderBySql);
			}			
			
			Query query = CreateQueryByEntity(session, cond, hql, condFields, like);
			
			if(query == null){
				logger.warn("create Query eror");
				return null;
			}

			if(page != null){
				int pageNum = 0;
				int pageSize = SysParamUtils.PAGE_MAX_SIZE;
				if(page.getPageCount() > 0 && page.getPageNumber() >= 0 && page.getPageSize() > 0){
					pageNum = page.getPageNumber() >= page.getPageCount() ? page.getPageCount() - 1 : page.getPageNumber();
					if(page.getPageSize() > 0 && pageSize > page.getPageSize()){
						pageSize = page.getPageSize(); 
					}
				}				
				query.setFirstResult(pageNum * pageSize);
				query.setMaxResults(pageSize);
			}
			
			data = (ArrayList<T>) query.list();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			data = null;
		}
		
		return data;
	}
	
	/**
	 * 按条件搜索所有记录。
	 * @param cond，条件。
	 * @param and，条件关系。
	 * @return，对象列表。
	 */
	public int searchCount(T cond, boolean and, boolean like, ArrayList<String> orderFields, boolean desc){
		return searchCount(getSession(cond), cond, and, like, orderFields, desc);
	}
	
	public int searchCount(Session session, T cond, boolean and, boolean like, ArrayList<String> orderFields, boolean desc){
		int count = -1;
		try {
			setTheadContext(cond);
			session.clear();
			ArrayList<Field> condFields = new ArrayList<>();
			String hql = CreateSearchSql(cond, and, like, condFields);
			if(hql == null){
				logger.warn("create HQL error");
				return -1;
			}
			hql = "select count(*) " + hql;
			
			Query query = CreateQueryByEntity(session, cond, hql, condFields, like);
			if(query == null){
				logger.warn("create Query eror");
				return -1;
			}
			count = ((Long)query.iterate().next()).intValue();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			return -1;
		}
		
		return count;
	}
	
	/**
	 * 自定义条件搜索记录
	 * @param table 表名
	 * @param woSql where和order子句
	 * @param page 查询页数
	 * @return
	 */
	public ArrayList<T> search(String table, String woSql, SearchPage page){
		return search(getSession(null), table, woSql, page);
	}
	
	public ArrayList<T> search(Session session, String table, String woSql, SearchPage page){
		if(page != null && (page.getPageCount() < 0 || page.getPageNumber() < 0 || page.getPageSize() < 0)){
			logger.warn("parameter is error");
			return null;
		}
		ArrayList<T> data = null;
		try {
			session.clear();
			String sql = String.format("select %s from %s %s", getSelectFields(), table, woSql);
			SQLQuery query = session.createSQLQuery(sql);
			query.addEntity(entityClass);

			if(page != null){
				int pageNum = page.getPageNumber();
				int pageSize = SysParamUtils.PAGE_MAX_SIZE;
				if(page.getPageCount() > 0 && page.getPageNumber() >= 0 && page.getPageSize() > 0){
					pageNum = page.getPageNumber() >= page.getPageCount() ? page.getPageCount() - 1 : page.getPageNumber();
					if(page.getPageSize() > 0 && pageSize > page.getPageSize()){
						pageSize = page.getPageSize();
					}
				}

				query.setFirstResult(pageNum * pageSize);
				query.setMaxResults(pageSize);
			}
			data = (ArrayList<T>) query.list();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			data = null;
		}
		return data;
	}
	
	public int searchCount(String table, String woSql){
		return searchCount(getSession(null), table, woSql);
	}
	
	public int searchCount(Session session, String table, String woSql){
		int count = -1;
		try {
			session.clear();
			String sql = String.format("select count(*) from %s %s", table, woSql == null ? "" : woSql);
			SQLQuery query = session.createSQLQuery(sql);
			count = ((BigInteger) query.list().get(0)).intValue();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			return -1;
		}
		
		return count;
	}
	public int searchDistinctCount(String table, String distinctname,String whereSql){
		return searchDistinctCount(getSession(null), table, distinctname, whereSql);
	}
	/**
	 * 查询不重复的数据
	 * @param session
	 * @param table
	 * @param distinctname
	 * @param whereSql
	 * @return
	 */
	public int searchDistinctCount(Session session, String table, String distinctname, String whereSql){
		int count = -1;
		try {
			session.clear();
			String sql = String.format("select count(%s) from %s %s", distinctname==null?"*":"distinct "+distinctname,table, whereSql == null ? "" : whereSql);
			SQLQuery query = session.createSQLQuery(sql);
			count = ((BigInteger) query.list().get(0)).intValue();
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			return -1;
		}
		
		return count;
	}
	
	/**
	 * 按条件删除所有记录。
	 * @param cond，条件。
	 * @param and，条件关系。
	 * @return 返回删除记录数。
	 */
	public int remove(T cond, boolean and){
		return remove(getSession(cond), cond, and);
	}
	
	public int remove(Session session, T cond, boolean and){
		int rows = -1;
		try {
			setTheadContext(cond);
			session.clear();
			ArrayList<Field> condFields = new ArrayList<>();
			String hql = CreateSearchSql(cond, and, false, condFields);
			if(hql == null){
				logger.warn("create HQL error");
				return -1;
			}
			hql = "delete " + hql;
			Query query = CreateQueryByEntity(session, cond, hql, condFields, false);
			if(query == null){
				logger.warn("create Query error");
				return -1;
			}
			rows = query.executeUpdate();
			session.flush();
			
			Cache entityCache = getCache();
			if(entityCache != null){
				entityCache.removeAll();
			}
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			rows = -1;
		}		
		
		return rows;
	}
	
	public String CreateSearchSql(T cond, boolean and, boolean like, ArrayList<Field> fieldList){
		String hql = null;
		try {
			hql = String.format("from %s t", entityClass.getSimpleName());
			Field fields[] = entityClass.getDeclaredFields();
			String where = "";
			for(Field f : fields){
				if(Modifier.isStatic(f.getModifiers())){
					continue;
				}
				if(!isColumnField(f.getName())){
					continue;
				}
				
				String strCond = queryByField(cond, and, like, fieldList, f);
				if(strCond != null && strCond.length() > 0){
					if(where.length() > 0){
						if(and){
							where += " and ";
						}else{
							where += " or ";
						}
					}
					where += strCond;
				}
			}
			if(where.trim().length() > 0){
				hql += " where" + where;
			}
		} catch (Exception e) {
			e.printStackTrace();
				this.restSession();
			logger.error(e.getMessage());
			return null;
		}
		return hql;
	}
	
	public Query CreateQueryByEntity(Session session, T cond, String hql, ArrayList<Field> condFields, boolean like){
		Query query = null;
		try {
			query = session.createQuery(hql);
			for (int i = 0; i < condFields.size(); i++) {
				Field f = condFields.get(i);
				switch (f.getType().getSimpleName().toLowerCase()) {
				case "long":
					query.setLong(f.getName(), (Long) PropertyUtils.getProperty(cond, f.getName()));
					break;
				case "int":
				case "integer":
					query.setInteger(f.getName(), (Integer) PropertyUtils.getProperty(cond, f.getName()));
					break;
				case "string":
					if(like){
						query.setString(f.getName(), "%" + (String) PropertyUtils.getProperty(cond, f.getName()) + "%");
					}else{
						query.setString(f.getName(), (String) PropertyUtils.getProperty(cond, f.getName()));
					}
					break;
				case "date":
					query.setTimestamp(f.getName(), (Date) PropertyUtils.getProperty(cond, f.getName()));
					break;
				default:
					logger.warn(String.format("data type %s is unsupported", f.getType().getSimpleName()));
					return null;
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
		return query;
	}
	
	public boolean zeroEntity(T entity){
		try {
			Field fields[] = entityClass.getDeclaredFields();
			for (Field f : fields) {
				if (Modifier.isStatic(f.getModifiers())){
					continue;
				}
				if (!isColumnField(f.getName())){
					continue;
				}

				switch (f.getType().getSimpleName()) {
				case "long":
				case "int":
					PropertyUtils.setProperty(entity, f.getName(), 0);
					break;
				default:
					break;
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	public void restSession(){
		dataSource = new ComboPooledDataSource("dataSource");
		ThreadContext tc = ThreadContext.getThreadContext();
		logger.warn("rest session!!!");
		tc.session.close();
		tc.session = null;
	}
	
	protected String queryByField(T cond, boolean and, boolean like, ArrayList<Field> fieldList, Field field){
		try {
			String r = null;
			switch(field.getType().getSimpleName().toLowerCase()){
			case "long":
			case "int":
			case "integer":
			case "biginteger":
			case "date":
				r = String.format(" = :%s", field.getName());
				break;
			case "string":
				if(like){
					r = String.format(" like :%s", field.getName());
				}else{
					r = String.format(" = :%s", field.getName());
				}
				break;
			default:
				return null;
			}
			
			Object val = PropertyUtils.getProperty(cond, field.getName());
			if (val == null){
				return null;
			}
			String type = field.getType().getSimpleName();
			if (("long".equals(type.toLowerCase()) || "int".equals(type.toLowerCase()) || "integer".equals(type.toLowerCase()) || "biginteger".equals(type.toLowerCase())) && Long.parseLong(val.toString()) <= 0){
				return null;
			}
			fieldList.add(field);
			r = String.format(" t.%s%s", field.getName(), r);
			return r;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
	}
	
	protected Cache getCache(){
		if(CacheManager.getInstance() != null){
			return CacheManager.getInstance().getCache(entityClass.getName());
		}
		return null;
	}
	
	protected String getEntityKey(T entity){
		if(fGetCacheKey == null){
			return null;
		}
		try {
			return (String) fGetCacheKey.invoke(entity);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		} 
	}

	protected synchronized boolean isColumnField(String name){
		try {
			if(tableFields == null){
				tableFields = new HashSet<>();
				embedFields = new HashSet<>();
				
				Field fields[] = entityClass.getDeclaredFields();
				for(Field f : fields){
					if(Modifier.isStatic(f.getModifiers())){
						continue;
					}
					
					if(!isFieldName(entityClass, f.getName())){
						if(f.getType().isPrimitive()){
							continue;
						}
						Class<?> cls = f.getType();
						if(cls.getAnnotation(javax.persistence.Embeddable.class) == null){
							continue;
						}
						embedFields.add(f.getName());
					}
				
					tableFields.add(f.getName());
				}
			}
			
			if(!tableFields.contains(name)){
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	private boolean isFieldName(Class<?> cls, String name){
		try {
			String fg = "get" + name.substring(0, 1).toUpperCase() + name.substring(1);
			Method m = cls.getMethod(fg);
			if (m == null){
				return false;
			}
			if (m.getAnnotation(Column.class) == null || m.getAnnotation(Transient.class) != null){
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	private synchronized String getSelectFields(){
		if(selectFields == null){
			selectFields = "";
			Field fields[] = entityClass.getDeclaredFields();
			for(Field f : fields){
				if(Modifier.isStatic(f.getModifiers())){
					continue;
				}
				if(!isColumnField(f.getName())){
					continue;
				}
				if(embedFields.contains(f.getName())){
					for(Field fe : f.getType().getDeclaredFields()){
						if(Modifier.isStatic(fe.getModifiers())){
							continue;
						}
						if(!isFieldName(fe.getType(), fe.getName())){
							continue;
						}
						String fieldName = getTableFieldName(fe);
						if(fieldName != null && fieldName.length() > 0){
							selectFields += fieldName + ", ";
						}
					}
				}
				String fieldName = getTableFieldName(f);
				if(fieldName != null && fieldName.length() > 0){
					selectFields += fieldName + ", ";
				}
			}
			selectFields = selectFields.substring(0, selectFields.length() - 2);
		}
		return selectFields;
	}
	
	private String getTableFieldName(Field field){
		try {
			String mn = "get" + field.getName().substring(0, 1).toUpperCase() + field.getName().substring(1);
			Method m = entityClass.getMethod(mn);
			if (m == null){
				return null;
			}
			Column an = m.getAnnotation(Column.class);
			if (an == null){
				return null;
			}
			return an.name();
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
			return null;
		}
	}
}
