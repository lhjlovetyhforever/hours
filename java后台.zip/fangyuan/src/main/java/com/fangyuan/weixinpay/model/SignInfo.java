package com.fangyuan.weixinpay.model;

import com.thoughtworks.xstream.annotations.XStreamAlias;

public class SignInfo {

	//小程序ID
	private String appId;
	//时间戳
	private String timeStamp;
	//随机串
	private String nonceStr;
	@XStreamAlias("package")
	private String prepay_id;
	//签名方式
	private String signType;
	
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getNonceStr() {
		return nonceStr;
	}
	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}
	public String getRepay_id() {
		return prepay_id;
	}
	public void setRepay_id(String prepay_id) {
		this.prepay_id = prepay_id;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	
	
	
}
