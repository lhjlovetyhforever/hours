package com.fangyuan.weixinpay.common;

public class Configure {
	private static String key = "shichuanglzqshichuanglzq2zhongji";
	//小程序ID	
	private static String appID = "wx33c3f4e63f481bda";
	//商户号
	private static String mch_id = "1505145631";
	//
	private static String secret = "57ce0c31e9f40117717cbd4b4b4c0698";

	public static String getSecret() {
		return secret;
	}

	public static void setSecret(String secret) {
		Configure.secret = secret;
	}

	public static String getKey() {
		return key;
	}

	public static void setKey(String key) {
		Configure.key = key;
	}

	public static String getAppID() {
		return appID;
	}

	public static void setAppID(String appID) {
		Configure.appID = appID;
	}

	public static String getMch_id() {
		return mch_id;
	}

	public static void setMch_id(String mch_id) {
		Configure.mch_id = mch_id;
	}

}
