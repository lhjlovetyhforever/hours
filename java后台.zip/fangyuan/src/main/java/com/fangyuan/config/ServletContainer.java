package com.fangyuan.config;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.ErrorPage;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class ServletContainer implements EmbeddedServletContainerCustomizer {

    @Override
    public void customize(ConfigurableEmbeddedServletContainer container) {
        //container.setPort(8443);

        container.addErrorPages(new ErrorPage(HttpStatus.BAD_REQUEST,"/400.json"));
        container.addErrorPages(new ErrorPage(HttpStatus.NOT_FOUND,"/404.json"));
        container.addErrorPages(new ErrorPage(HttpStatus.METHOD_NOT_ALLOWED,"/405.json"));
        container.addErrorPages(new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR,"/500.json"));
        container.setSessionTimeout(1000, TimeUnit.MINUTES);
    }
}
