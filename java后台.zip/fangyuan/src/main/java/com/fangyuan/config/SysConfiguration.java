package com.fangyuan.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import java.beans.PropertyVetoException;
import java.sql.SQLException;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
public class SysConfiguration implements EnvironmentAware {

        private Environment environment;
        private RelaxedPropertyResolver datasourcePropertyResolver;

        //从application.yml中读取资源
        @Override
        public void setEnvironment(Environment environment) {
            this.environment = environment;
            this.datasourcePropertyResolver = new RelaxedPropertyResolver(environment,
                    "spring.datasource.");
        }


        @Bean(name="dataSource")
        @Qualifier(value="dataSource")//限定描述符除了能根据名字进行注入，但能进行更细粒度的控制如何选择候选者
        @Primary//用@Primary区分主数据源
        @ConfigurationProperties(prefix="c3p0.primary")//指定配置文件中，前缀为c3p0的属性值
        public ComboPooledDataSource dataSource(){

            ComboPooledDataSource data = null;

            data = (ComboPooledDataSource) DataSourceBuilder.create().type(ComboPooledDataSource.class).build();

            try {

                data.setDriverClass("com.mysql.cj.jdbc.Driver");
                data.setJdbcUrl(datasourcePropertyResolver.getProperty("url"));
                data.setUser(datasourcePropertyResolver.getProperty("username"));
                data.setPassword(datasourcePropertyResolver.getProperty("password"));

                data.setMaxPoolSize(80);
                data.setMinPoolSize(2);
                data.setMaxStatements(80);
                data.setInitialPoolSize(10);
                data.setMaxIdleTime(30);
                data.setTestConnectionOnCheckin(false);
                data.setTestConnectionOnCheckout(true);
                data.setPreferredTestQuery("SELECT 1");
                //定期使用连接池内的连接，使得它们不会因为闲置超时而被 MySQL 断开
                data.setIdleConnectionTestPeriod(30);
                data.setTestConnectionOnCheckout(true);
                data.setIdleConnectionTestPeriod(20);

            } catch (PropertyVetoException e) {
                e.printStackTrace();
            }

            return data;
            //创建数据源
        }
        //sessionFactory的定义
        @Bean
        public LocalSessionFactoryBean sessionFactory() throws SQLException{

            LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();

            //入数据源
            localSessionFactoryBean.setDataSource(this.dataSource());
            localSessionFactoryBean.setPackagesToScan("*");
            localSessionFactoryBean.setPackagesToScan("com.fangyuan.entity");

            Properties properties1 = new Properties();
            properties1.setProperty("hibernate.dialect","org.hibernate.dialect.MySQL5Dialect");
            properties1.setProperty("hibernate.show_sql","true");
            properties1.setProperty("hibernate.current_session_context_class","thread");
            properties1.setProperty("hibernate.cache.use_query_cache","false");
            properties1.setProperty("hibernate.cache.use_second_level_cache","false");
            properties1.setProperty("hibernate.cache.region.factory_class","org.hibernate.cache.ehcache.EhCacheRegionFactory");
            properties1.setProperty("hibernate.net.sf.ehcache.configurationResourceName","ehcache.xml");

            localSessionFactoryBean.setHibernateProperties(properties1);

            return localSessionFactoryBean;
        }


        //事务管理的配置
        @Bean
        public HibernateTransactionManager transactionManager() throws SQLException {

            HibernateTransactionManager hibernateTransactionManager = new HibernateTransactionManager();

            hibernateTransactionManager.setSessionFactory(sessionFactory().getObject());

            return hibernateTransactionManager;
        }
        @Bean
        public TransactionInterceptor transactionInterceptor(){
            TransactionInterceptor tr = new TransactionInterceptor();
            try {
                tr.setTransactionManager(transactionManager());
                Properties ps = new Properties();
                ps.put("save*","PROPAGATION_REQUIRED");
                ps.put("insert*","PROPAGATION_REQUIRED");
                ps.put("create*","PROPAGATION_REQUIRED");
                ps.put("update*","PROPAGATION_REQUIRED");
                ps.put("delete*","PROPAGATION_REQUIRED");
                ps.put("remove*","PROPAGATION_REQUIRED");
                ps.put("batch*","PROPAGATION_REQUIRED");
                ps.put("execute*","PROPAGATION_REQUIRED");
                ps.put("get*","PROPAGATION_REQUIRED,readOnly");
                ps.put("find*","PROPAGATION_REQUIRED,readOnly");
                ps.put("query*","PROPAGATION_REQUIRED,readOnly");
                ps.put("search*","PROPAGATION_REQUIRED,readOnly");
                tr.setTransactionAttributes(ps);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return tr;
        }
}
