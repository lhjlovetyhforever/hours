package com.fangyuan.listener;

import com.fangyuan.utils.ErrorCodeUtil;
import com.fangyuan.utils.SysParamUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;


@Component
public class SysInitListener implements ApplicationContextAware{


    private WebApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext arg0) throws BeansException {
        context = (WebApplicationContext) arg0;
        SysParamUtils.initSystemParams(context);
        ErrorCodeUtil.initSysErrorCode(context);
    }
}
