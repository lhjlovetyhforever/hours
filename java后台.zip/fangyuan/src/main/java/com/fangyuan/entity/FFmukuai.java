package com.fangyuan.entity;

import javax.persistence.*;

@Entity
@Table(name = "f_fangzidetail")
public class FFmukuai {
    private int fid;
    private String fmodularName;
    private String value;
    private int pid;
    private  int delflag;


    @Id
    @Column(name = "fId",unique = true,nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getFid() {
        return fid;
    }
    public void setFid(int fid) {
        this.fid = fid;
    }

    @Column(name = "fModularName")
    public String getFmodularName() {
        return fmodularName;
    }
    public void setFmodularName(String fmodularName) {
        this.fmodularName = fmodularName;
    }
    @Column(name = "value")
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    @Column(name = "pId")
    public int getPid() {
        return pid;
    }
    public void setPid(int pid) {
        this.pid = pid;
    }

    @Column(name = "delFlag")
    public int getDelflag() {
        return delflag;
    }
    public void setDelflag(int delflag) {
        this.delflag = delflag;
    }
}
