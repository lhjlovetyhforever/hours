package com.fangyuan.entity;

import javax.persistence.*;

@Entity
@Table(name = "f_fangyuan_min")
public class FFangyuanMinModule {

    private int id;
    private int maxId;
    private String minTitle;
    private Double money;
    private Double uploadMoney;

    @Id
    @Column(name = "id",nullable = false,unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public FFangyuanMinModule() {
    }

    public FFangyuanMinModule(int id) {
        this.id = id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "maxId")
    public int getMaxId() {
        return maxId;
    }

    public void setMaxId(int maxId) {
        this.maxId = maxId;
    }

    @Column(name = "minTitle")
    public String getMinTitle() {
        return minTitle;
    }

    public void setMinTitle(String minTitle) {
        this.minTitle = minTitle;
    }

    @Column(name = "money")
    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    @Column(name = "uploadMoney")
    public Double getUploadMoney() {
        return uploadMoney;
    }

    public void setUploadMoney(Double uploadMoney) {
        this.uploadMoney = uploadMoney;
    }
}
