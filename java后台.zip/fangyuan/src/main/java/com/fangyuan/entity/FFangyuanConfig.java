package com.fangyuan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "f_fangyuan_config")
public class FFangyuanConfig {
    private int id;
    private Double uploadMoney;

    @Id
    @Column(name = "id",unique = true,nullable = false)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    @Column(name = "uploadMoney")
    public Double getUploadMoney() {
        return uploadMoney;
    }

    public void setUploadMoney(Double uploadMoney) {
        this.uploadMoney = uploadMoney;
    }
}
