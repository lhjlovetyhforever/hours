package com.fangyuan.entity;


import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "f_fangyuan")
public class FFangYuan {
    private int fid;
    /**
     * 名称
     */
    private String name;
    /**
     * 电话
     */
    private String tel;
    /**
     * 价格
     */
    private Double price;
    /**
     * 发布时间
     */
    private Date time;
    /**
     * 描述
     */
    private String detail;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 户型
     */
    private String huxing;
    /**
     * 面积
     */
    private Double mianji;
    /**
     * 租金
     */
    private Double zujin;

    @Id
    @Column(name = "fyid",unique = true,nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getFid() {
        return fid;
    }
    public void setFid(int fid) {
        this.fid = fid;
    }

    @Column(name = "fyName")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "fyTel")
    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Column(name = "fyPrice")
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Column(name = "fyTime")
    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @Column(name = "fyDetail")
    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    @Column(name = "fyaddress")
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Column(name = "fyHuxing")
    public String getHuxing() {
        return huxing;
    }

    public void setHuxing(String huxing) {
        this.huxing = huxing;
    }

    @Column(name = "fyMianji")
    public Double getMianji() {
        return mianji;
    }

    public void setMianji(Double mianji) {
        this.mianji = mianji;
    }

    @Column(name = "fyZujin")
    public Double getZujin() {
        return zujin;
    }

    public void setZujin(Double zujin) {
        this.zujin = zujin;
    }
}
