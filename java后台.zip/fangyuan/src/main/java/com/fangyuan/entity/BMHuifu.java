package com.fangyuan.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "t_bm_huifu")
public class BMHuifu {
    private int hfId;
    private int lyId;
    private int activeId;
    private String openId;
    private String nickName;
    private String touxiang;
    private String content;
    private String target;
    private Date createTime;

    @Id
    @Column(name = "hfId",unique = true,nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getHfId() {
        return hfId;
    }

    public void setHfId(int hfId) {
        this.hfId = hfId;
    }

    @Column(name = "lyId")
    public int getLyId() {
        return lyId;
    }

    public void setLyId(int lyId) {
        this.lyId = lyId;
    }

    @Column(name = "activeId")
    public int getActiveId() {
        return activeId;
    }

    public void setActiveId(int activeId) {
        this.activeId = activeId;
    }

    @Column(name = "openId")
    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    @Column(name = "nickName")
    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    @Column(name = "touxiang")
    public String getTouxiang() {
        return touxiang;
    }

    public void setTouxiang(String touxiang) {
        this.touxiang = touxiang;
    }

    @Column(name = "content")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Column(name = "target")
    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    @Column(name = "createTime")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
