package com.fangyuan.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "t_bm_active")
public class BMActive {

    private int activeId;
    private String title;
    private String template;
    private String content;
    private String img_one;
    private String img_two;
    private String img_three;
    private String img_foue;
    private String img_five;
    private String img_six;
    private String img_seven;
    private String img_eight;
    private String img_neight;
    private int isPay;
    private Double money;
    private String leaderId;
    private String leader;
    private Integer personNumber;
    private Integer fileNumber;
    private Integer forward;
    private Integer cell_req;
    private Integer cell_name;
    private String address;
    private String latitude;
    private String longitude;
    private Date createTime;
    private String endTime;
    @Id
    @Column(name = "activeId",unique = true,nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getActiveId() {
        return activeId;
    }

    public void setActiveId(int activeId) {
        this.activeId = activeId;
    }

    @Column(name = "leaderId")
    public String getLeaderId() {
        return leaderId;
    }

    public void setLeaderId(String leaderId) {
        this.leaderId = leaderId;
    }

    @Column(name = "title")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Column(name = "template")
    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    @Column(name = "content")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Column(name = "img_one")
    public String getImg_one() {
        return img_one;
    }

    public void setImg_one(String img_one) {
        this.img_one = img_one;
    }

    @Column(name = "img_two")
    public String getImg_two() {
        return img_two;
    }

    public void setImg_two(String img_two) {
        this.img_two = img_two;
    }

    @Column(name = "img_three")
    public String getImg_three() {
        return img_three;
    }

    public void setImg_three(String img_three) {
        this.img_three = img_three;
    }

    @Column(name = "img_four")
    public String getImg_foue() {
        return img_foue;
    }

    public void setImg_foue(String img_foue) {
        this.img_foue = img_foue;
    }

    @Column(name = "img_five")
    public String getImg_five() {
        return img_five;
    }

    public void setImg_five(String img_five) {
        this.img_five = img_five;
    }

    @Column(name = "img_six")
    public String getImg_six() {
        return img_six;
    }

    public void setImg_six(String img_six) {
        this.img_six = img_six;
    }

    @Column(name = "img_seven")
    public String getImg_seven() {
        return img_seven;
    }

    public void setImg_seven(String img_seven) {
        this.img_seven = img_seven;
    }

    @Column(name = "img_eight")
    public String getImg_eight() {
        return img_eight;
    }

    public void setImg_eight(String img_eight) {
        this.img_eight = img_eight;
    }

    @Column(name = "img_neight")
    public String getImg_neight() {
        return img_neight;
    }

    public void setImg_neight(String img_neight) {
        this.img_neight = img_neight;
    }

    @Column(name = "isPay")
    public int getIsPay() {
        return isPay;
    }

    public void setIsPay(int isPay) {
        this.isPay = isPay;
    }

    @Column(name = "money")
    public Double getMoney() {
        return money;
    }

    public void setMoney(Double money) {
        this.money = money;
    }

    @Column(name = "leader")
    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    @Column(name = "limitOfNumber")
    public Integer getPersonNumber() {
        return personNumber;
    }

    public void setPersonNumber(Integer personNumber) {
        this.personNumber = personNumber;
    }

    @Column(name = "fileNumber")
    public Integer getFileNumber() {
        return fileNumber;
    }

    public void setFileNumber(Integer fileNumber) {
        this.fileNumber = fileNumber;
    }

    @Column(name = "forward")
    public Integer getForward() {
        return forward;
    }

    public void setForward(Integer forward) {
        this.forward = forward;
    }

    @Column(name = "cell_req")
    public Integer getCell_req() {
        return cell_req;
    }

    public void setCell_req(Integer cell_req) {
        this.cell_req = cell_req;
    }

    @Column(name = "cell_name")
    public Integer getCell_name() {
        return cell_name;
    }

    public void setCell_name(Integer cell_name) {
        this.cell_name = cell_name;
    }

    @Column(name = "address")
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Column(name = "latitude")
    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    @Column(name = "longitude")
    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @Column(name = "createTime")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Column(name = "endTime")
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
