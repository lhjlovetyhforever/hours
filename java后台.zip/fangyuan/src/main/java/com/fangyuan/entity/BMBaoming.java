package com.fangyuan.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "t_bm_baoming")
public class BMBaoming {
    private BMBaomingId baomingId;
    private String userName;
    private String touxiang;
    private String phone;
    private Date joinTime;

    @EmbeddedId
    @AttributeOverrides({ @AttributeOverride(name = "openId", column = @Column(name = "openId", nullable = false) ),
            @AttributeOverride(name = "activeId", column = @Column(name = "activeId", nullable = false) ) })
    public BMBaomingId getBaomingId() {
        return baomingId;
    }

    public void setBaomingId(BMBaomingId baomingId) {
        this.baomingId = baomingId;
    }

    @Column(name = "userName")
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Column(name = "phone")
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Column(name = "joinTime")
    public Date getJoinTime() {
        return joinTime;
    }

    public void setJoinTime(Date joinTime) {
        this.joinTime = joinTime;
    }

    @Column(name = "touxiang")
    public String getTouxiang() {
        return touxiang;
    }

    public void setTouxiang(String touxiang) {
        this.touxiang = touxiang;
    }
}
