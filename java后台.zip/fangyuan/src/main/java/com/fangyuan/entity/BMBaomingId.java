package com.fangyuan.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class BMBaomingId implements Serializable{
    private String openId;
    private Integer activeId;

    @Column(name = "openId")
    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    @Column(name = "activeId")
    public Integer getActiveId() {
        return activeId;
    }

    public void setActiveId(Integer activeId) {
        this.activeId = activeId;
    }

    @Override
    public boolean equals(Object other) {
        if ((this == other)){
            return true;
        }
        if ((other == null)){
            return false;
        }
        if (!(other instanceof BMBaomingId)){
            return false;
        }
        BMBaomingId castOther = (BMBaomingId) other;
        return (this.getOpenId() == castOther.getOpenId()) && (this.getActiveId() == castOther.getActiveId());
    }

    @Override
    public int hashCode() {
        int result = openId.hashCode();
        result = 31 * result + activeId;
        return result;
    }
}
