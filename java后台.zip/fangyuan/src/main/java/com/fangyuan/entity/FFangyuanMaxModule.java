package com.fangyuan.entity;

import javax.persistence.*;

@Entity
@Table(name = "f_fangyuan_max")
public class FFangyuanMaxModule {

    private int id;
    private String title;

    @Id
    @Column(name = "id",nullable = false,unique = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "title")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public FFangyuanMaxModule() {
    }

    public FFangyuanMaxModule(int id) {
        this.id = id;
    }
}
