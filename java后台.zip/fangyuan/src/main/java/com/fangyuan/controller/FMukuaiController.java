package com.fangyuan.controller;

import com.fangyuan.dto.Result;
import com.fangyuan.entity.FFmukuai;
import com.fangyuan.service.FMukuaiService;
import com.fangyuan.utils.ErrorCodeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

@Controller
public class FMukuaiController {

    @Autowired
    private FMukuaiService fMukuaiService;

    @RequestMapping(value = "/fangyuan/addmukuai")
    @ResponseBody
    public void addMukuai(@RequestParam (value = "Pidandvalue") String Pidandvalue){
        String [] PinandVlue=Pidandvalue.split(",");
        String Pid=PinandVlue[0];
        String fvalue=PinandVlue[1];
        FFmukuai fFmukuai=new FFmukuai();
        fFmukuai.setFmodularName(fMukuaiService.getFmukuaiOne(Integer.parseInt(Pid)).getFmodularName());
        fFmukuai.setPid(Integer.parseInt(Pid));
        fFmukuai.setValue(fvalue);
        fFmukuai.setDelflag(1); 
       fMukuaiService.addMukuai(fFmukuai);
    }

    @RequestMapping(value = "/fangyuan/getPmukuai",method = RequestMethod.GET)
    @ResponseBody
    public Result getPmukuai(@RequestParam(value = "type",required = false) Integer type){
        Result re=new Result();
        re.setData(fMukuaiService.getPMukuai(type));
        re.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return re;
    }
    @RequestMapping(value = "/fangyuan/getAllchild",method = RequestMethod.GET)
    @ResponseBody
    public Result getAllChild(@RequestParam(value = "Pid") int Pid){
        Result re=new Result();
        re.setData(fMukuaiService.getAllChild(Pid));
        re.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return  re;
    }

    @RequestMapping(value = "/fangyuan/delChildMokuai")
    @ResponseBody
    public void delChildMokuai(@RequestParam (value = "Fid") int Fid){
        System.out.print("Fid="+Fid);
        FFmukuai f=new FFmukuai();
        f.setFid(Fid);
        fMukuaiService.delfMokuai(f);
    }


    @RequestMapping(value = "/fangyuan/goChildMokuai",method = RequestMethod.GET)
    public ModelAndView goAddmukuai(@RequestParam (value = "Pid") int Pid){
        ModelAndView model=new ModelAndView();
        System.out.print("Pid="+Pid);
        model.setViewName("AddMoKuai");
        model.addObject("Pid",Pid);
        return model;
    }

    @RequestMapping(value = "/fangyuan/goSelMukuai",method = RequestMethod.GET)
    public String goSelMukuai(){
        return "SelMoKuai";
    }

    @RequestMapping(value = "/fangyuan/updateMk",method = RequestMethod.GET)
    @ResponseBody
    public void updateMukuai(@RequestParam (value = "FidandVlue")String FidandVlue){
        String [] PinandVlue=FidandVlue.split(",");
        String Fid=PinandVlue[0];
        String fvalue=PinandVlue[1];
        FFmukuai   f=fMukuaiService.getFmukuaiOne(Integer.parseInt(Fid));
        f.setValue(fvalue);
        fMukuaiService.updateFmukuai(f);
    }
}
