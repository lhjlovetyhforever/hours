package com.fangyuan.controller;

import com.fangyuan.dto.Result;
import com.fangyuan.utils.ErrorCodeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

@Controller
public class FileController {

    private static final Logger logger = LoggerFactory.getLogger(FileController.class);

    /**
     * 女生经常用的图片保存基础地址
     */
    public static final String DOWNLOAD_66 = "C://file/img/";
    /**
     * 点击查看全文的图片保存基础地址
     */
    public static final String DOWNLOAD_77 = "C://file/djckqw/";
    /**
     * 女神经常用的图片保存基础地址
     */
    public static final String DOWNLOAD_81 = "C://美颜接口/Web/";

    /**
     * 文件上传
     * @return
     */
    @RequestMapping(value = "/baoming/upload", method = RequestMethod.POST)
    @ResponseBody
    public Result upload(@RequestParam(value = "one",required = false) MultipartFile one) {
        Result result = new Result();
//        if (file.isEmpty()) {
//            result.setCode(ErrorCodeUtil.ERROR_NULL_FILE);
//            return result;
//        }
        // 文件上传后的路径
        String filePath = "C://file//img//baoming//";
        // 获取文件名
        if(one!=null){
            String fileName_one = one.getOriginalFilename();
            File dest_one = new File(filePath+ fileName_one);
            // 检测是否存在目录
            if (!dest_one.getParentFile().exists()) {
                dest_one.setWritable(true);
                dest_one.setReadable(true);
                dest_one.setExecutable(true);
                dest_one.getParentFile().mkdirs();
            }
            try {
                one.transferTo(dest_one);
            } catch (Exception e) {
                e.printStackTrace();
                result.setCode(ErrorCodeUtil.ERROR_SYSTEM);
                return result;
            }

        }
//        if(two!=null){
//            String fileName_two = two.getName();
//            File dest_two = new File(filePath+ fileName_two);
//            // 检测是否存在目录
//            if (!dest_two.getParentFile().exists()) {
//                dest_two.setWritable(true);
//                dest_two.setReadable(true);
//                dest_two.setExecutable(true);
//                dest_two.getParentFile().mkdirs();
//            }
//            try {
//                two.transferTo(dest_two);
//            } catch (Exception e) {
//                e.printStackTrace();
//                result.setCode(ErrorCodeUtil.ERROR_SYSTEM);
//                return result;
//            }
//        }
//        if(three!=null){
//            String fileName_three = three.getName();
//            File dest_three = new File(filePath+ fileName_three);
//            // 检测是否存在目录
//            if (!dest_three.getParentFile().exists()) {
//                dest_three.setWritable(true);
//                dest_three.setReadable(true);
//                dest_three.setExecutable(true);
//                dest_three.getParentFile().mkdirs();
//            }
//            try {
//                three.transferTo(dest_three);
//            } catch (Exception e) {
//                e.printStackTrace();
//                result.setCode(ErrorCodeUtil.ERROR_SYSTEM);
//                return result;
//            }
//        }
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }


    /**
     * 多文件上传
     * @param request
     * @return
     */
    @RequestMapping(value = "/batch/upload", method = RequestMethod.POST)
    @ResponseBody
    public String handleFileUpload(HttpServletRequest request) {
        List<MultipartFile> files = ((MultipartHttpServletRequest) request)
                .getFiles("file");
        MultipartFile file = null;
        BufferedOutputStream stream = null;
        for (int i = 0; i < files.size(); ++i) {
            file = files.get(i);
            if (!file.isEmpty()) {
                try {
                    byte[] bytes = file.getBytes();
                    stream = new BufferedOutputStream(new FileOutputStream(
                            new File(file.getOriginalFilename())));
                    stream.write(bytes);
                    stream.close();
                } catch (Exception e) {
                    stream = null;
                    return "You failed to upload " + i + " => "
                            + e.getMessage();
                }
            } else {
                return "You failed to upload " + i
                        + " because the file was empty.";
            }
        }
        return "upload successful";
    }

    /**
     * 文件下载
     * @param res
     */
    @RequestMapping(value = "/download", method = RequestMethod.GET)
    public void testDownload(HttpServletResponse res,@RequestParam(value = "url") String url,@RequestParam(value = "host") String host) {
        String fileName = "upload.jpg";
        res.setHeader("content-type", "application/octet-stream");
        res.setContentType("application/octet-stream");
        res.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        byte[] buff = new byte[1024];
        BufferedInputStream bis = null;
        OutputStream os = null;
        try {
            os = res.getOutputStream();
            if("66".equals(host)){
                bis = new BufferedInputStream(new FileInputStream(new File(DOWNLOAD_66+url)));
            }else if("81".equals(host)){
                bis = new BufferedInputStream(new FileInputStream(new File(DOWNLOAD_81+url)));
            }else if("77".equals(host)){
                bis = new BufferedInputStream(new FileInputStream(new File(DOWNLOAD_77+url)));
            }
            int i = bis.read(buff);
            while (i != -1) {
                os.write(buff, 0, buff.length);
                os.flush();
                i = bis.read(buff);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    logger.error(e.getMessage());
                    e.printStackTrace();
                }
            }
            if(os!=null){
                try{
                    os.close();
                }catch (Exception e){
                    e.printStackTrace();
                    logger.error(e.getMessage());
                }
            }
        }
        System.out.println("success");
    }

}
