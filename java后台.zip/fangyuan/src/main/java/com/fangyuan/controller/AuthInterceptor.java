package com.fangyuan.controller;


import com.fangyuan.dao.ThreadContext;
import com.fangyuan.service.AuthService;
import com.fangyuan.utils.StringUtils;
import com.fangyuan.utils.SysParamUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * 接口消息鉴权。<br/>
 * 一次鉴权需要头字段 Timestamp(yyyy-MM-dd HH:mm:ss (Z)) 和 Auth。<br/>
 * 二次鉴权还需要头字段 once 和 code。<br/>
 */
@Repository
public class AuthInterceptor implements HandlerInterceptor {


    private static Logger logger = Logger.getLogger(AuthInterceptor.class);

    public static final String BASE_PATH = "/";

    @Autowired
    private AuthService authService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        logger.info(" preHandle ");

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Allow-Headers", "*");

        ThreadContext.getThreadContext().setOpenId(null);
        ThreadContext.getThreadContext().setRequest(request);
        if(request.getRequestURI().contains("/web/")||request.getRequestURI().toString().length()>0){
            return true;
        }
        String strOperId = request.getHeader("openId");

        int isRegister = request.getRequestURI().indexOf("/user/register");

        if( isRegister != -1){

            return true;

        } else {

            String openId = null;

            if (strOperId!=null){
                openId = strOperId;
            }
            if(strOperId == null || "".equals(openId)){
                response.setContentType("application/json;charset=utf-8");
                PrintWriter pw = response.getWriter();
                //定义返回json
                String result = String.format("{\"code\":401,\"reason\":\"%s\"}","验证失败，操作人不明确！");
                result = StringUtils.getOutNetStting(result);
                pw.println(result);
                return false;
            }
            ThreadContext.getThreadContext().setOpenId(openId);
        }

        do{
            if(SysParamUtils.Process != null && SysParamUtils.Process.equals(SysParamUtils.PROCESS_DEBUG)){
                break;
            }

            logger.info(String.format("receive %s request for URL %s from client %s", request.getMethod(), request.getRequestURI(), request.getRemoteAddr()));
            String timestamp = request.getHeader("Timestamp");
            String Auth = request.getHeader("Auth");
            boolean flag = authService.verifyToken(timestamp, Auth, strOperId);
            if(!flag){
                logger.warn(String.format("请求验证失败；Timestamp %s, Auth : %s", timestamp, Auth));
                response.setContentType("application/json;charset=utf-8");
                PrintWriter pw = response.getWriter();
                //定义返回json
                String result = String.format("{\"code\":401,\"reason\":\"%s\"}","请求验证失败！");
                result = StringUtils.getOutNetStting(result);
                pw.println(result);
                return false;
            }

        }while(false);

//请求日志待完善
/*       if(!requestLogService.writeRequestLog(request)){
            logger.warn("write request log error");
        }
*/
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

        logger.info(" postHandle ");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Allow-Headers", "*");
        ThreadContext context = ThreadContext.getThreadContext();
        try{
            context.getSession().close();
        }catch (Exception e){
            logger.warn("session已经关闭!!!");
        }
        context.setSession(null);
        context.setOpenId(null);
        context.setDao(null);
        context.setEntity(null);
        context.setRequest(null);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        logger.info(" afterCompletion ");
    }
}
