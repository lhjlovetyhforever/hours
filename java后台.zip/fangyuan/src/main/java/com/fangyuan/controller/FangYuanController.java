package com.fangyuan.controller;

import com.fangyuan.dto.FangyuanEight;
import com.fangyuan.dto.Result;
import com.fangyuan.entity.FFangYuan;
import com.fangyuan.entity.FFangyuanEight;
import com.fangyuan.entity.FFangyuanMaxModule;
import com.fangyuan.entity.FFangyuanMinModule;
import com.fangyuan.service.FangYuanService;
import com.fangyuan.utils.DataUtils;
import com.fangyuan.utils.ErrorCodeUtil;
import com.fangyuan.utils.NetUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

@Controller
public class FangYuanController {

    @Autowired
    private FangYuanService fangYuanService;
    private static final Logger logger = Logger.getLogger(FangYuanController.class);

    /**
     * 根据房源Id获取房源信息
     * @param fyid 房源Id
     * @return
     */
    @RequestMapping(value = "/fangyuan",method = RequestMethod.GET)
    public Result getFangYuan(@RequestParam(value = "fyid") int fyid){
        Result result = new Result();
        ArrayList<FFangYuan> list = new ArrayList<>();
        FFangYuan fangYuan = fangYuanService.getFangYuan(fyid);
        list.add(fangYuan);
        result.setData(list);
        return result;
    }

    /**
     * 添加房源信息
     * @param request FFangYuan实体
     * @return
     */
    @RequestMapping(value = "/fangyuan/add",method = RequestMethod.POST)
    public String addFungYuan(HttpServletRequest request){
        Result result = new Result();
        ArrayList<FFangYuan> list = new ArrayList<>();
        FFangYuan fangYuan = new FFangYuan();
        try{
            fangYuan.setAddress(request.getParameter("address"));
            fangYuan.setDetail(request.getParameter("detail"));
            fangYuan.setHuxing(request.getParameter("huxing"));
            fangYuan.setName(request.getParameter("name"));
            fangYuan.setTel(request.getParameter("tel"));
            try{
                fangYuan.setMianji(Double.valueOf(request.getParameter("mianji")));
            }catch (Exception e){
                logger.warn(e.getMessage());
            }
            try{
                fangYuan.setPrice(Double.valueOf(request.getParameter("price")));
            }catch (Exception e){
                logger.warn(e.getMessage());
            }
            try{
                fangYuan.setZujin(Double.valueOf(request.getParameter("zujin")));
            }catch (Exception e){
                logger.warn(e.getMessage());
            }
            fangYuan.setTime(new Date());
            fangYuan = fangYuanService.addFangYuan(fangYuan);
            result.setCode(ErrorCodeUtil.ERROR_REQUEST_PARAMETER);
        }catch (Exception e){
            logger.error(e.getMessage());
        }
        if(fangYuan!=null){
            result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
            list.add(fangYuan);
        }
        result.setData(list);
        return "page/addFangYuan";
    }

    /**
     * 根据条件查询房源
     * @return 结果集
     */
    @RequestMapping(value = "/fangyuan/search",method = RequestMethod.POST)
    @ResponseBody
    public Result searchFangYuan(HttpServletRequest request,
                                @RequestParam(value = "minZujin",required = false) Integer minZujin,
                                @RequestParam(value = "maxZujin",required = false) Integer maxZujin,
                                @RequestParam(value = "minMianji",required = false) Integer minMianji,
                                @RequestParam(value = "maxMianji",required = false) Integer maxMianji
                                 ){
        Result result = new Result();
        String json = NetUtils.getHttpRequestBody(request);
        HashMap<String, String> map = null;
        try{
            map = DataUtils.json2HashMap(json);
        }catch (Exception e){
            logger.warn(e.getMessage());
        }
        String address = null;
        String huxing = null;
        try{
            if(map.containsKey("address")){
                address = map.get("address");
            }
            if(map.containsKey("huxing")){
                huxing = map.get("huxing");
            }
        }catch (Exception e){
            logger.error(e.getMessage());
        }
        ArrayList<FFangYuan> fFangYuans = fangYuanService.searchFangYuan(address, huxing, minMianji,maxMianji, minZujin,maxZujin);
        result.setData(fFangYuans);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    @RequestMapping(value = "/fangyuan/add",method = RequestMethod.GET)
    public String addFangYuan(){
        return "page/addFangYuan";
    }

    @RequestMapping(value = "/fangyuan/delete",method = RequestMethod.DELETE)
    public String deleteFangYuan(@RequestParam(value = "id") int id){
        fangYuanService.deleteFangYuan(id);
        return "page/addFangYuan";
    }

    @RequestMapping(value = "/fangyuan/update",method = RequestMethod.POST)
    public String updateFangyuan(@RequestParam(value = "id") String fyid) throws UnsupportedEncodingException {
        fyid =URLDecoder.decode(fyid,"utf-8");
        String detail = fyid.split("\\|")[1];
        Double price = Double.parseDouble(fyid.split("\\|")[2]);
        int id = Integer.parseInt(fyid.split("\\|")[0]);
        fangYuanService.updateFangyuan(id,detail,price);
        return "page/addFangYuan";
    }


    @RequestMapping(value = "/fangyuan/module/add",method = RequestMethod.GET)
    public String addLocalModule(){
        return "page/addLocalModule";
    }

    @RequestMapping(value = "/fangyuan/eight/add",method = RequestMethod.GET)
    public String addLocal(){
        return "page/addLocal";
    }

    /**
     * 添加大模块
     * @return
     */
    @RequestMapping(value = "/fangyuan/module/max",method = RequestMethod.POST)
    public String addMaxModule(@RequestParam(value = "title") String title) throws UnsupportedEncodingException {
        title = URLDecoder.decode(title, "utf-8");
        fangYuanService.addMaxModule(title);
        return "page/addLocalModule";
    }

    /**
     * 添加小模块
     * @return
     */
    @RequestMapping(value = "/fangyuan/module/min",method = RequestMethod.POST)
    public String addMinModule(@RequestParam(value = "data") String data) throws UnsupportedEncodingException {
        data = URLDecoder.decode(data,"utf-8");
        int maxId = Integer.parseInt(data.split("\\|")[0]);
        String minTitle = data.split("\\|")[1];
        Double money = Double.parseDouble(data.split("\\|")[2]);
        Double uploadMoney = Double.parseDouble(data.split("\\|")[3]);
        FFangyuanMinModule minModule = new FFangyuanMinModule();
        minModule.setMaxId(maxId);
        minModule.setMinTitle(minTitle);
        minModule.setMoney(money);
        minModule.setUploadMoney(uploadMoney);
        fangYuanService.addMinModule(minModule);
        return "page/addLocalModule";
    }

    /**
     * 查询模块
     * @return
     */
    @RequestMapping(value = "/fangyuan/module/search",method = RequestMethod.GET)
    @ResponseBody
    public Result queryModule(){
        Result result = new Result();
        result = fangYuanService.queryModule(result);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 删除大模块
     * @param id
     * @return
     */
    @RequestMapping(value = "/fangyuan/maxModule/del",method = RequestMethod.DELETE)
    public String delMaxModule(@RequestParam(value = "id") int id){
        fangYuanService.delMaxModule(id);
        return "page/addLocalModule";
    }

    /**
     * 删除下模块
     * @param id
     * @return
     */
    @RequestMapping(value = "/fangyuan/minModule/del",method = RequestMethod.DELETE)
    public String delMinModule(@RequestParam(value = "id") int id){
        fangYuanService.delMinModule(id);
        return "page/addLocalModule";
    }

    /**
     * 添加房源其他信息
     * @return
     */
    @RequestMapping(value = "/fangyuan/eight/add",method = RequestMethod.POST)
//    public Result addEight(@RequestParam(value = "data") String data) throws UnsupportedEncodingException {
    public String addEight(@RequestParam(value = "maxId") int maxId,@RequestParam(value = "minId") int minId,@RequestParam(value = "title",required = false) String title,
                           @RequestParam(value = "content") String content,@RequestParam(value = "phone") String phone){
//        data = URLDecoder.decode(data,"utf-8");
//        Result result = new Result();
//        FFangyuanEight eight = new FFangyuanEight();
//        String[] split = data.split("\\|");
//        eight.setMinId(Integer.parseInt(split[0]));
//        eight.setMaxId(Integer.parseInt(split[1]));
//        eight.setContent(split[2]);
//        eight.setPhone(split[3]);
//        eight.setTime(new Date());
//        Result result = new Result();
        FFangyuanEight eight = new FFangyuanEight();
        eight.setTitle(title);
        eight.setMaxId(maxId);
        eight.setMinId(minId);
        eight.setPhone(phone);
        eight.setContent(content);
        eight.setTime(new Date());
        fangYuanService.addEight(eight);
//        result.setData(list);
//        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return "page/addLocal";
    }


    /**
     * 大模块更新
     * @param data
     * @return
     */
    @RequestMapping(value = "/fangyuan/maxModule/update",method = RequestMethod.POST)
    @ResponseBody
    public Boolean updateMaxModule(@RequestParam(value = "data") String data) throws UnsupportedEncodingException {
        data = URLDecoder.decode(data,"utf-8");
        String[] split = data.split("\\|");
        int id = Integer.parseInt(split[0]);
        String title = split[1];
        fangYuanService.updateMaxModule(id,title);
        return true;
    }

    /**
     * 小模块更新
     * @param data
     * @return
     */
    @RequestMapping(value = "/fangyuan/minModule/update",method = RequestMethod.POST)
    @ResponseBody
    public Boolean updateMinModule(@RequestParam(value = "data") String data) throws UnsupportedEncodingException {
        data = URLDecoder.decode(data,"utf-8");
        String[] split = data.split("\\|");
        int id = Integer.parseInt(split[0]);
        int type = Integer.parseInt(split[1]);
        String minTitle = split[2];
        Double uploadMoney = Double.parseDouble(split[3]);
        Double money = Double.parseDouble(split[4]);
        fangYuanService.updateMinModule(id,type,minTitle,uploadMoney,money);
        return true;
    }

    /**
     * 查询其他用户上传信息
     * @param data
     * @return
     * @throws UnsupportedEncodingException
     */
    @RequestMapping(value = "/fangyuan/eight/search",method = RequestMethod.GET)
    @ResponseBody
    public Result searchEight(@RequestParam(value = "data",required = false) String data) throws UnsupportedEncodingException {
        Result result = new Result();
        Integer minId = null;
        try{
            data = URLDecoder.decode(data,"utf-8");
             minId = Integer.parseInt(data);
        }catch (Exception e){
            logger.warn("未获取到data");
        }
        ArrayList<FangyuanEight> list = fangYuanService.searchEight(minId);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 删除本地信息数据
     * @return
     */
    @RequestMapping(value = "/fangyuan/eight/del",method = RequestMethod.DELETE)
    public String delEight(@RequestParam(value = "id") int id){
        fangYuanService.delEight(id);
        return "page/addLocal";
    }

    /**
     * 更新本地服务信息
     * @param data
     * @return
     */
    @RequestMapping(value = "/fangyuan/eight/update",method = RequestMethod.POST)
    @ResponseBody
    public String updateEight(@RequestParam(value = "data") String data) throws UnsupportedEncodingException {
//    public String updateEight(@RequestParam(value = "id") int id,@RequestParam(value = "content") String content){
        data = URLDecoder.decode(data,"utf-8");
        String[] split = data.split("\\|");
        int id = Integer.parseInt(split[0]);
        String content = split[1];
        fangYuanService.updateEight(id,content);
        return "page/addLocal";
    }

}
