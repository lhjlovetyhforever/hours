package com.fangyuan.controller;

import com.fangyuan.entity.FFangyuanConfig;
import com.fangyuan.service.FangYuanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ConfigController {
    @Autowired
    FangYuanService fangYuanService;

    @RequestMapping(value = "/fangyuan/config",method = RequestMethod.GET)
    @ResponseBody
    public FFangyuanConfig getConfig(){
        return fangYuanService.getConfig();
    }

    @RequestMapping(value = "/fangyuan/config",method = RequestMethod.POST)
    @ResponseBody
    public Boolean updateConfig(@RequestParam(value = "uploadMoney") Double uploadMoney){
        fangYuanService.updateConfig(uploadMoney);
        return true;
    }
}
