package com.fangyuan.controller;

import com.alibaba.fastjson.JSONObject;
import com.fangyuan.dto.LiuYan;
import com.fangyuan.dto.Result;
import com.fangyuan.entity.*;
import com.fangyuan.service.BaoMingService;
import com.fangyuan.utils.DataUtils;
import com.fangyuan.utils.ErrorCodeUtil;
import com.fangyuan.utils.NetUtils;
import com.fangyuan.weixinpay.common.Configure;
import com.fangyuan.weixinpay.common.HttpRequest;
import com.fangyuan.weixinpay.common.RandomStringGenerator;
import com.fangyuan.weixinpay.common.Signature;
import com.fangyuan.weixinpay.model.OrderInfo;
import com.fangyuan.weixinpay.model.OrderReturnInfo;
import com.fangyuan.weixinpay.model.SignInfo;
import com.thoughtworks.xstream.XStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

@Controller
public class BaoMingController {

    private static final String APPID = "wxb0dea7346bcf0c08";
    private static final String SECRET = "a0a7fcbd98ed9141cb840003d64d01ed";

    @Autowired
    private BaoMingService baoMingService;

    /**
     * 获取openId
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = "/baoming/openid",method = RequestMethod.GET)
    public void getOpenId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        HttpGet httpGet = new HttpGet("https://api.weixin.qq.com/sns/jscode2session?appid="+ APPID
                +"&secret="+SECRET
                +"&js_code="+code
                +"&grant_type=authorization_code");
        //设置请求器的配置
        HttpClient httpClient = HttpClients.createDefault();
        HttpResponse res = httpClient.execute(httpGet);
        HttpEntity entity = res.getEntity();
        String result = EntityUtils.toString(entity, "UTF-8");

        System.out.print("========"+result);
        response.getWriter().append(result);
    }

    /**
     * 查询我创建的活动
     * @param openId
     * @return
     */
    @RequestMapping(value = "/baoming/active2my",method = RequestMethod.GET)
    @ResponseBody
    public Result getMyActive(@RequestParam(value = "openId") String openId){
        Result result = new Result();
        ArrayList<BMActive> list =  baoMingService.getActive2My(openId);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 查询我报名的所有活动
     * @param openId
     * @return
     */
    @RequestMapping(value = "/baoming/baoming/search",method = RequestMethod.GET)
    @ResponseBody
    public Result searchMyJoinActive(@RequestParam(value = "openId") String openId){
        Result result = new Result();
        ArrayList<BMActive> list = baoMingService.searchMyJoinActive(openId);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 根据活动Id查询单个活动
     * @param activeId
     * @return
     */
    @RequestMapping(value = "/baoming/active",method = RequestMethod.GET)
    @ResponseBody
    public Result getActive(@RequestParam(value = "activeId") int activeId){
        ArrayList<BMActive> list = new ArrayList<>();
        Result result = new Result();
        BMActive active = baoMingService.getActive(activeId);
        list.add(active);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 用户留言
     * @param request
     * @return
     */
    @RequestMapping(value = "/baoming/liuyan/add",method = RequestMethod.POST)
    @ResponseBody
    public Result addLiuyan(HttpServletRequest request){
        Result result = new Result();
        ArrayList<BMLiuyan> list = new ArrayList<>();
        String json = NetUtils.getHttpRequestBody(request);
        BMLiuyan liuyan = DataUtils.Json2Object(json, BMLiuyan.class);
        liuyan.setCreateTime(new Date());
        liuyan = baoMingService.addLiuyan(liuyan);
        list.add(liuyan);
        result.setData(list);
        return result;
    }

    /**
     * 回复留言
     * @param request
     * @return
     */
    @RequestMapping(value = "/baoming/huifu/add",method = RequestMethod.POST)
    @ResponseBody
    public Result addHuifu(HttpServletRequest request){
        Result result = new Result();
        ArrayList<BMHuifu> list = new ArrayList<>();
        String json = NetUtils.getHttpRequestBody(request);
        BMHuifu huifu = DataUtils.Json2Object(json, BMHuifu.class);
        huifu.setCreateTime(new Date());
        huifu = baoMingService.addHuifu(huifu);
        list.add(huifu);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 用户报名
     * @param request
     * @return
     */
    @RequestMapping(value = "/baoming/baoming/add",method = RequestMethod.POST)
    @ResponseBody
    public Result joinActive(HttpServletRequest request){
        ArrayList<BMBaoming> list = new ArrayList<>();
        Result result = new Result();
        String json = NetUtils.getHttpRequestBody(request);
        HashMap<String, String> map = DataUtils.json2HashMap(json);
        BMBaomingId baomingId = new BMBaomingId();
        baomingId.setOpenId(map.get("openId").toString());
        baomingId.setActiveId(Integer.parseInt(map.get("activeId").toString()));
        BMBaoming baoming = new BMBaoming();
        baoming.setBaomingId(baomingId);
        baoming.setTouxiang(map.get("touxiang").toString());
        try{
            baoming.setUserName(map.get("userName").toString());
            baoming.setPhone(map.get("phone").toString());
        }catch (Exception e){
            System.out.println("没填写用户名跟手机号");
        }
        baoming.setJoinTime(new Date());
        baoming = baoMingService.joinActive(baoming);
        list.add(baoming);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 查询活动对应的留言板
     * @param activeId 活动Id
     * @return 留言板
     */
    @RequestMapping(value = "/baoming/liuyan/all",method = RequestMethod.GET)
    @ResponseBody
    public Result getAllLiuyan(@RequestParam(value = "activeId") int activeId){
        Result result = new Result();
        ArrayList<LiuYan> liuYans = baoMingService.getAllLiuyan(activeId);
        result.setData(liuYans);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

//    /**
//     * 发布活动
//     * @param title
//     * @param templete
//     * @param content
//     * @param img_one
//     * @param img_two
//     * @param img_three
//     * @param isPay
//     * @param money
//     * @param leader
//     * @param address
//     * @param limitOfNumber
//     * @param fileNumber
//     * @param forword
//     * @param cell_req
//     * @param cell_name
//     * @return
//     */
//    @RequestMapping(value = "/baoming/baoming",method = RequestMethod.POST)
//    @ResponseBody
//    public Result addActive(@RequestParam(value = "title",required = false) String title,
//                                @RequestParam(value = "templete",required = false) String templete,
//                                @RequestParam(value = "content",required = false) String content,
//                                @RequestParam(value = "img_one",required = false) String img_one,
//                                @RequestParam(value = "img_two",required = false) String img_two,
//                                @RequestParam(value = "img_three",required = false) String img_three,
//                                @RequestParam(value = "img_foue",required = false) String img_foue,
//                                @RequestParam(value = "img_five",required = false) String img_five,
//                                @RequestParam(value = "img_six",required = false) String img_six,
//                                @RequestParam(value = "img_seven",required = false) String img_seven,
//                                @RequestParam(value = "img_eight",required = false) String img_eight,
//                                @RequestParam(value = "img_neight",required = false) String img_neight,
//                                @RequestParam(value = "isPay",required = false) Integer isPay,
//                                @RequestParam(value = "money",required = false) Double money,
//                                @RequestParam(value = "leaderId",required = false) String leaderId,
//                                @RequestParam(value = "leader",required = false) String leader,
//                                @RequestParam(value = "address",required = false) String address,
//                                @RequestParam(value = "latitude",required = false) String latitude,
//                                @RequestParam(value = "longitude",required = false) String longitude,
//                                @RequestParam(value = "personNumber",required = false) Integer  limitOfNumber,
//                                @RequestParam(value = "fileNumber",required = false) Integer fileNumber,
//                                @RequestParam(value = "forward",required = false) Integer forword,
//                                @RequestParam(value = "cell_req",required = false) Integer cell_req,
//                                @RequestParam(value = "cell_name",required = false) Integer cell_name,
//                                @RequestParam(value = "endTime",required = false) String endTime
//                            ){
//        Result result = new Result();
//        ArrayList<BMActive> list = new ArrayList<>();
//        try{
//            BMActive active = new BMActive();
//            active.setCell_name(cell_name);
//            active.setCell_req(cell_req);
//            active.setContent(content);
//            active.setFileNumber(fileNumber);
//            active.setForward(forword);
//            try{
//                active.setImg_one(img_one);
//                active.setImg_two(img_two);
//                active.setImg_three(img_three);
//                active.setImg_foue(img_foue);
//                active.setImg_five(img_five);
//                active.setImg_six(img_six);
//                active.setImg_seven(img_seven);
//                active.setImg_eight(img_eight);
//                active.setImg_neight(img_neight);
//            }catch (Exception e){
//                System.out.println("图片未选择");
//            }
//            active.setIsPay(isPay);
//            active.setLeader(leader);
//            active.setPersonNumber(limitOfNumber);
//            active.setMoney(money);
//            active.setTemplate(templete);
//            active.setLatitude(latitude);
//            active.setLongitude(longitude);
//            active.setAddress(address);
//            active.setTitle(title);
//            active.setLeaderId(leaderId);
//            active.setCreateTime(new Date());
//            active.setEndTime(endTime);
//            active = baoMingService.addActive(active);
//            list.add(active);
//            result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
//        }catch (Exception e){
//            result.setCode(ErrorCodeUtil.ERROR_SYSTEM);
//        }
//        result.setData(list);
//        return result;
//    }

    @RequestMapping(value = "/baoming/baoming",method = RequestMethod.POST)
    @ResponseBody
    public Result addActive(HttpServletRequest request){
        Result result = new Result();
        ArrayList<BMActive> list = new ArrayList<>();
        String json = NetUtils.getHttpRequestBody(request);
        BMActive bmActive = DataUtils.Json2Object(json, BMActive.class);
        bmActive.setCreateTime(new Date());
        bmActive = baoMingService.addActive(bmActive);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        list.add(bmActive);
        result.setData(list);
        return result;
    }

    /**
     * 删除活动
     * @return
     */
    @RequestMapping(value = "/baoming/active/delete",method = RequestMethod.DELETE)
    @ResponseBody
    public void deleteActive(@RequestParam(name = "activeId") int activeId){
        baoMingService.deleteActive(activeId);
    }

    /**
     * 更新活动
     * @param request
     * @return
     */
    @RequestMapping(value = "/baoming/active/update",method = RequestMethod.PUT)
    @ResponseBody
    public boolean updateActive(HttpServletRequest request){
        String json = NetUtils.getHttpRequestBody(request);
        BMActive active = DataUtils.Json2Object(json, BMActive.class);
        return baoMingService.updateActive(active);
    }

    /**
     * 看过活动的人
     * 添加
     */
    @RequestMapping(value = "/baoming/active/look",method = RequestMethod.POST)
    @ResponseBody
    public void lookActive(@RequestParam(value = "openId") String openId,
                           @RequestParam(value = "touxiang") String touxiang,
                           @RequestParam(value = "activeId") int activeId){
        baoMingService.lookActive(openId,touxiang,activeId);
    }

    /**
     * 看过活动的人
     * 查看
     * @param activeId
     * @return
     */
    @RequestMapping(value = "/baoming/active/look",method = RequestMethod.GET)
    @ResponseBody
    public Result getLookActive(@RequestParam(value = "activeId") int activeId){
        Result result = new Result();
        ArrayList<BMLookActive> list = baoMingService.getLookActive(activeId);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 用户注册
     * @param request
     * @return
     */
    @RequestMapping(value = "/baoming/user/regeist",method = RequestMethod.POST)
    @ResponseBody
    public Result regeistUser(HttpServletRequest request){
        Result result = new Result();
        ArrayList<BMUser> list = new ArrayList<>();
        String json = NetUtils.getHttpRequestBody(request);
        BMUser user = DataUtils.Json2Object(json, BMUser.class);
        user = baoMingService.regeistUser(user);
        list.add(user);
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 查询报了名的人
     * @param activeId
     * @return
     */
    @RequestMapping(value = "/baoming/active/search",method = RequestMethod.GET)
    @ResponseBody
    public Result searchBaoming(@RequestParam(value = "activeId") int activeId){
        ArrayList<BMBaoming> list = baoMingService.searchBaoming(activeId);
        Result result = new Result();
        result.setData(list);
        result.setCode(ErrorCodeUtil.ERROR_SUCCESS);
        return result;
    }

    /**
     * 下单
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = "/baoming/pay/xiadan",method = RequestMethod.GET)
    public void xiadan(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String openid = request.getParameter("openid");
            int money = Integer.parseInt(request.getParameter("money"));
            OrderInfo order = new OrderInfo();
            order.setAppid("wxb0dea7346bcf0c08");
            order.setMch_id(Configure.getMch_id());
            order.setNonce_str(RandomStringGenerator.getRandomStringByLength(32));
            order.setBody("付费查看详情");
            order.setOut_trade_no(RandomStringGenerator.getRandomStringByLength(32));
            order.setTotal_fee(money);
            order.setSpbill_create_ip("210.4.132.123");
            order.setNotify_url("https://www.see-source.com/weixinpay/PayResult");
            order.setTrade_type("JSAPI");
            order.setOpenid(openid);
            order.setSign_type("MD5");
            //生成签名
            String sign = Signature.getSign(order);
            order.setSign(sign);

            String result = HttpRequest.sendPost("https://api.mch.weixin.qq.com/pay/unifiedorder", order);
            System.out.println(result);
            XStream xStream = new XStream();
            xStream.alias("xml", OrderReturnInfo.class);
            OrderReturnInfo returnInfo = (OrderReturnInfo)xStream.fromXML(result);
            JSONObject json = new JSONObject();
            System.out.print(returnInfo.getPrepay_id());
            json.put("prepay_id", returnInfo.getPrepay_id());
            response.getWriter().append(json.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 签名
     */
    @RequestMapping(value = "/baoming/pay/sign",method = RequestMethod.GET)
    public void sign(HttpServletRequest request,HttpServletResponse response){
        try {
            String repay_id = request.getParameter("repay_id");
            SignInfo signInfo = new SignInfo();
            signInfo.setAppId("wxb0dea7346bcf0c08");
            long time = System.currentTimeMillis()/1000;
            signInfo.setTimeStamp(String.valueOf(time));
            signInfo.setNonceStr(RandomStringGenerator.getRandomStringByLength(32));
            signInfo.setRepay_id("prepay_id="+repay_id);
            signInfo.setSignType("MD5");
            //生成签名
            String sign = Signature.getSign(signInfo);

            JSONObject json = new JSONObject();
            json.put("timeStamp", signInfo.getTimeStamp());
            json.put("nonceStr", signInfo.getNonceStr());
            json.put("package", signInfo.getRepay_id());
            json.put("signType", signInfo.getSignType());
            json.put("paySign", sign);
            response.getWriter().append(json.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 是否报名
     * @param activeId
     * @param openId
     * @return
     */
    @RequestMapping(value = "/baoming/active/isbaoming",method = RequestMethod.GET)
    @ResponseBody
    public boolean isBaoming(@RequestParam(value = "activeId") int activeId,@RequestParam(value = "openId") String openId){
        return baoMingService.isBaoming(activeId,openId);
    }

    /**
     * 取消报名
     * @param openId
     * @param activeId
     * @return
     */
    @RequestMapping(value = "/baoming/baoming/delete",method = RequestMethod.DELETE)
    @ResponseBody
    public boolean cancelBaoming(@RequestParam(value = "openId") String openId,@RequestParam("activeId") int activeId){
        return baoMingService.cancelBaoming(activeId,openId);
    }

}
