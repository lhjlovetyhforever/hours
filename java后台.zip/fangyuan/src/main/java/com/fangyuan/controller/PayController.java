package com.fangyuan.controller;

import com.alibaba.fastjson.JSONObject;
import com.fangyuan.weixinpay.common.Configure;
import com.fangyuan.weixinpay.common.HttpRequest;
import com.fangyuan.weixinpay.common.RandomStringGenerator;
import com.fangyuan.weixinpay.common.Signature;
import com.fangyuan.weixinpay.model.OrderInfo;
import com.fangyuan.weixinpay.model.OrderReturnInfo;
import com.fangyuan.weixinpay.model.SignInfo;
import com.thoughtworks.xstream.XStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
public class PayController {

    private static final Logger L = Logger.getLogger(PayController.class);

    /**
     * 获取openId
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = "/fangyuan/openid",method = RequestMethod.GET)
    public void getOpenId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        HttpGet httpGet = new HttpGet("https://api.weixin.qq.com/sns/jscode2session?appid="+ Configure.getAppID()
                +"&secret="+Configure.getSecret()
                +"&js_code="+code
                +"&grant_type=authorization_code");
        //设置请求器的配置
        HttpClient httpClient = HttpClients.createDefault();
        HttpResponse res = httpClient.execute(httpGet);
        HttpEntity entity = res.getEntity();
        String result = EntityUtils.toString(entity, "UTF-8");
        System.out.print("========"+result);
        response.getWriter().append(result);
    }

    /**
     * 下单
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = "/fangyuan/pay/xiadan",method = RequestMethod.GET)
    public void xiadan(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String openid = request.getParameter("openid");
            int money = Integer.parseInt(request.getParameter("money"));
            OrderInfo order = new OrderInfo();
            order.setAppid(Configure.getAppID());
            order.setMch_id(Configure.getMch_id());
            order.setNonce_str(RandomStringGenerator.getRandomStringByLength(32));
            order.setBody("付费查看详情");
            order.setOut_trade_no(RandomStringGenerator.getRandomStringByLength(32));
            order.setTotal_fee(money);
            order.setSpbill_create_ip("210.4.132.123");
            order.setNotify_url("https://www.see-source.com/weixinpay/PayResult");
            order.setTrade_type("JSAPI");
            order.setOpenid(openid);
            order.setSign_type("MD5");
            //生成签名
            String sign = Signature.getSign(order);
            order.setSign(sign);

            String result = HttpRequest.sendPost("https://api.mch.weixin.qq.com/pay/unifiedorder", order);
            System.out.println(result);
            L.info("---------下单返回:"+result);
            XStream xStream = new XStream();
            xStream.alias("xml", OrderReturnInfo.class);
            OrderReturnInfo returnInfo = (OrderReturnInfo)xStream.fromXML(result);
            JSONObject json = new JSONObject();
            json.put("prepay_id", returnInfo.getPrepay_id());
            response.getWriter().append(json.toJSONString());
        } catch (Exception e) {
            e.printStackTrace();
            L.error("-------", e);
        }
    }

    /**
     * 签名
     */
    @RequestMapping(value = "/fangyuan/pay/sign",method = RequestMethod.GET)
    public void sign(HttpServletRequest request,HttpServletResponse response){
        try {
            String repay_id = request.getParameter("repay_id");
            SignInfo signInfo = new SignInfo();
            signInfo.setAppId(Configure.getAppID());
            long time = System.currentTimeMillis()/1000;
            signInfo.setTimeStamp(String.valueOf(time));
            signInfo.setNonceStr(RandomStringGenerator.getRandomStringByLength(32));
            signInfo.setRepay_id("prepay_id="+repay_id);
            signInfo.setSignType("MD5");
            //生成签名
            String sign = Signature.getSign(signInfo);

            JSONObject json = new JSONObject();
            json.put("timeStamp", signInfo.getTimeStamp());
            json.put("nonceStr", signInfo.getNonceStr());
            json.put("package", signInfo.getRepay_id());
            json.put("signType", signInfo.getSignType());
            json.put("paySign", sign);
            L.info("-------再签名:"+json.toJSONString());
            response.getWriter().append(json.toJSONString());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            L.error("-------", e);
        }
    }

}
