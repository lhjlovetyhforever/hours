package com.fangyuan.service;

import com.fangyuan.dao.*;
import com.fangyuan.dto.FangyuanEight;
import com.fangyuan.dto.Result;
import com.fangyuan.entity.*;
import com.fangyuan.utils.DataUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class FangYuanService {
    @Autowired
    private FFangYuanDao fangYuanDao;
    @Autowired
    private FFangyuanMaxModuleDao maxModuleDao;
    @Autowired
    private FFangyuanMinModuleDao minModuleDao;
    @Autowired
    private FFangyuanEightDao eightDao;
    @Autowired
    FFangyuanConfgDao confgDao;

    public FFangYuan getFangYuan(int fyid){
        FFangYuan fangYuan = new FFangYuan();
        fangYuan.setFid(fyid);
        return fangYuanDao.get(fangYuan,fyid);
    }

    public FFangYuan addFangYuan(FFangYuan fangYuan){
        ArrayList<FFangYuan> search = fangYuanDao.search("f_fangyuan", " where fytel = '" + fangYuan.getTel() + "'", null);
        if(search!=null&&search.size()>0){
            for (FFangYuan ff :
                    search) {
                fangYuanDao.delete(ff);
            }
        }
        return fangYuanDao.insert(fangYuan);
    }

    public ArrayList<FFangYuan> searchFangYuan(String address,String huxing,Integer minMianji,Integer maxMianji,Integer minZujin,Integer maxZujin){
        StringBuilder sql = new StringBuilder();
        sql.append(" where  DATE_SUB(CURDATE(), INTERVAL 7 DAY) <= date(fytime) ");
        if(address!=null){
            sql.append(" and fyaddress = '"+address+"' ");
        }
        if(huxing!=null){
            sql.append(" and fyHuxing = '"+huxing+"' ");
        }
        if(minZujin!=null&&maxZujin!=null){
            sql.append(" and ((fyZujin >= "+minZujin+" and fyZujin <= "+maxZujin+" )or fyZujin is null) ");
        }else if(minZujin!=null&&maxZujin==null){
            sql.append(" and (fyZujin >= "+minZujin+" or fyZujin  is null) ");
        }else if(minZujin==null&&maxZujin!=null){
            sql.append(" and (fyZujin <= "+maxZujin+" or fyZujin  is null) ");
        }

        if(minMianji!=null&&maxMianji!=null){
            sql.append(" and ((fyMianji >="+minMianji+" and fyMianji <= "+maxMianji+") or fyMianji is null) ");
        }else if(minMianji!=null&&maxMianji==null){
            sql.append(" and (fyMianji >="+minMianji+" or fyMianji  is null) ");
        }else if(minMianji==null&&maxMianji!=null){
            sql.append(" and (fyMianji <= "+maxMianji+" or fyMianji  is null) ");
        }
        sql.append(" order by fyid desc ");
        return fangYuanDao.search("f_fangyuan",sql.toString(),null);
    }

    public boolean deleteFangYuan(int id) {
        FFangYuan fangYuan = new FFangYuan();
        fangYuan.setFid(id);
        return fangYuanDao.delete(fangYuan);
    }

    public void updateFangyuan(int fyid, String detail, double price) {
        FFangYuan fangYuan = new FFangYuan();
        fangYuan.setFid(fyid);
        fangYuan = fangYuanDao.get(fangYuan, fyid);
        fangYuan.setDetail(detail);
        fangYuan.setPrice(price);
        fangYuanDao.update(fangYuan);
    }

    public void addMaxModule(String title) {
        FFangyuanMaxModule module = new FFangyuanMaxModule();
        module.setTitle(title);
        maxModuleDao.insert(module);
    }

    public void addMinModule(FFangyuanMinModule minModule){
        minModuleDao.insert(minModule);
    }

    public void delMaxModule(int id){
        FFangyuanMaxModule maxModule = new FFangyuanMaxModule();
        maxModule.setId(id);
        maxModuleDao.delete(maxModule);
        ArrayList<FFangyuanMinModule> f_fangyaun_min = minModuleDao.search("f_fangyaun_min", String.format(" where maxId = %d ", id), null);
        if(f_fangyaun_min==null||f_fangyaun_min.size()<=0){
            return;
        }
        for(FFangyuanMinModule m:f_fangyaun_min){
            minModuleDao.delete(m);
        }
    }

    public void delMinModule(int id){
        FFangyuanMinModule minModule = new FFangyuanMinModule();
        minModule.setId(id);
        minModuleDao.delete(minModule);
    }

    public Result queryModule(Result result) {
        ArrayList<FFangyuanMaxModule> f_fangyuan_max = maxModuleDao.search("f_fangyuan_max", "", null);
        ArrayList<FFangyuanMinModule> f_fangyuan_min = minModuleDao.search("f_fangyuan_min", "", null);
        result.setEight(f_fangyuan_min);
        result.setData(f_fangyuan_max);
        return result;
    }

    public void addEight(FFangyuanEight eight) {
        eightDao.insert(eight);
    }

    public void updateMaxModule(int id, String title) {
        FFangyuanMaxModule maxModule = new FFangyuanMaxModule();
        maxModule.setId(id);
        maxModule = maxModuleDao.get(maxModule,id);
        try{
            maxModule.setTitle(title);
            maxModuleDao.update(maxModule);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void updateMinModule(int id, int type, String minTitle, Double uploadMoney, Double money) {
        FFangyuanMinModule minModule = new FFangyuanMinModule();
        minModule.setId(id);
        minModule = minModuleDao.get(minModule,id);
        try{
            minModule.setUploadMoney(uploadMoney);
            minModule.setMoney(money);
            minModule.setMinTitle(minTitle);
            minModule.setMaxId(type);
            minModuleDao.update(minModule);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public ArrayList<FangyuanEight> searchEight(Integer minId) {
        ArrayList<FFangyuanEight> eight = new ArrayList<>();
        if(minId==null){
            eight = eightDao.search("f_fangyuan_eight", " where DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(time) order by id desc ", null);
        }else{
            eight = eightDao.search("f_fangyuan_eight", String.format(" where minId = %d and DATE_SUB(CURDATE(), INTERVAL 30 DAY) <= date(time) order by id desc ", minId), null);
        }
        FangyuanEight fangyuanEight ;
        ArrayList<FangyuanEight> list = new ArrayList<>();
        for(FFangyuanEight e:eight){
            fangyuanEight = new FangyuanEight();
            DataUtils.CopyBean(e,fangyuanEight);
            try{
                fangyuanEight.setMaxTitle(maxModuleDao.get(new FFangyuanMaxModule(e.getMaxId()),e.getMaxId()).getTitle());
                fangyuanEight.setMinTitle(minModuleDao.get(new FFangyuanMinModule(e.getMinId()),e.getMinId()).getMinTitle());
            }catch (Exception ex){
                System.out.println("未找到本条数据,已跳过");
                continue;
            }
            list.add(fangyuanEight);
        }
        return list;
    }

    public void delEight(int id) {
        FFangyuanEight eight = new FFangyuanEight();
        eight.setId(id);
        eightDao.delete(eight);
    }

    public void updateEight(int id,String content){
        FFangyuanEight eight = new FFangyuanEight();
        eight.setId(id);
        try{
            eight = eightDao.get(eight,id);
            eight.setContent(content);
            eightDao.update(eight);
        }catch (Exception e){
            System.out.println("获取本地服务信息出错!");
        }
    }

    public FFangyuanConfig getConfig(){
        FFangyuanConfig config = new FFangyuanConfig();
        config.setId(1);
        return confgDao.get(config,1);
    }

    public void updateConfig(Double uploadMoney) {
        FFangyuanConfig config = new FFangyuanConfig();
        config.setId(1);
        config.setUploadMoney(uploadMoney);
        confgDao.update(config);
    }
}
