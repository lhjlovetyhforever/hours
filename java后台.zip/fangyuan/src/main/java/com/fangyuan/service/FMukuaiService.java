package com.fangyuan.service;

import com.fangyuan.dao.FMukuaiDao;
import com.fangyuan.entity.FFmukuai;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class FMukuaiService {
    @Autowired
    private FMukuaiDao fMukuaiDao;

    private static final Logger logger = Logger.getLogger(FMukuaiService.class);

    /**
     * 查询所有模块
     * @return
     */
    public ArrayList<FFmukuai> getAllMukuai(){
        ArrayList<FFmukuai> list = null;
        try{
            list =fMukuaiDao.search("f_fangzidetail"," where delFlag=1",null);
        }catch (Exception e){
            logger.error(e.getMessage());
        }
        return list;
    }
    /**
     * 添加模块
     * */
    public int addMukuai(FFmukuai fFmukuai){
        fMukuaiDao.insert(fFmukuai);
        return  0;
    }

    /**
     * 查询大模块
     * @return
     */
    public ArrayList<FFmukuai> getPMukuai(Integer type){
        ArrayList<FFmukuai> list=fMukuaiDao.search("f_fangzidetail",type==null?" where delFlag=1 and Pid=0 ":" where delFlag=1 and Pid<>0 ",null);
        return list;
    }

    /**
     * 查询所有的小模块
     * @return
     */
    public ArrayList<FFmukuai> getAllChild(int Pid){
        return fMukuaiDao.search("f_fangzidetail","where delFlag=1 and Pid="+Pid,null);
    }

    /**
     * 根据大模块ID查询内容
     * @param Pid
     * @return
     */
    public ArrayList<FFmukuai> getChildMukuai(int Pid){
        ArrayList<FFmukuai> list=fMukuaiDao.search("f_fangzidetail"," where delFlag=1 and Pid ="+Pid,null);
        return list;
    }

    /**
     * 删除小模块
     * @param fFmukuai
     * @return
     */
    public int delfMokuai(FFmukuai fFmukuai){
        fMukuaiDao.delete(fFmukuai);
        return 0;
    }

    /**
     * 查询单独的大模块
     * @param id
     * @return
     */
    public FFmukuai getFmukuaiOne(int id){
        FFmukuai ff=  new FFmukuai();
        ff.setFid(id);
       return   fMukuaiDao.get(ff,id);

    }
    public int updateFmukuai(FFmukuai fFmukuai){
        fMukuaiDao.update(fFmukuai);
        return 0;
    }
}
