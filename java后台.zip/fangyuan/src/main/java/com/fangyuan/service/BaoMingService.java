package com.fangyuan.service;

import com.fangyuan.dao.*;
import com.fangyuan.dto.LiuYan;
import com.fangyuan.entity.*;
import com.fangyuan.utils.DataUtils;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class BaoMingService {

    @Autowired
    private BMActiveDao activeDao;
    @Autowired
    private BMBaomingDao baomingDao;
    @Autowired
    private BMLiuyanDao liuyanDao;
    @Autowired
    private BMHuifuDao huifuDao;
    @Autowired
    private BMLookActiveDao lookActiveDao;
    @Autowired
    private BMUserDao userDao;

    public ArrayList<BMActive> getActive2My(String openId) {
        return activeDao.search("t_bm_active",String.format(" where leaderId = '%s' order by createTime desc ",openId),null);
    }

    public BMActive getActive(int activeId){
        BMActive active = new BMActive();
        active.setActiveId(activeId);
        return activeDao.get(active,activeId);
    }

    public ArrayList<BMActive> searchMyJoinActive(String openId){
        Session session = baomingDao.getSession(null);
        ArrayList<BMBaoming> lists = new ArrayList<>();
        ArrayList<BMActive> actives = new ArrayList<>();
        String sql = " select * from t_bm_baoming where openId = '"+openId+"' order by joinTime desc  ";
        SQLQuery query = session.createSQLQuery(sql);
        List list = query.list();
        for (int i = 0;i<list.size();i++) {
            Object obj[] = (Object[]) list.get(i);
            BMBaomingId baomingId = new BMBaomingId();
            baomingId.setOpenId(obj[0].toString());
            baomingId.setActiveId(Integer.parseInt(obj[1].toString()));
            actives.add(getActive(Integer.parseInt(obj[1].toString())));
            BMBaoming baoming = new BMBaoming();
            baoming.setTouxiang(obj[5].toString());
            try{
                baoming.setUserName(obj[2].toString());
                baoming.setPhone(obj[3].toString());
            }catch (Exception e){
                e.printStackTrace();
            }
            baoming.setJoinTime((Date) obj[4]);
            baoming.setBaomingId(baomingId);
            lists.add(baoming);
        }
        return actives;
    }

    public BMLiuyan addLiuyan(BMLiuyan liuyan) {
        return liuyanDao.insert(liuyan);
    }

    public BMHuifu addHuifu(BMHuifu huifu) {
        return huifuDao.insert(huifu);
    }

    public BMBaoming joinActive(BMBaoming baoming) {
        return baomingDao.insert(baoming);
    }

    public ArrayList<LiuYan> getAllLiuyan(int activeId) {
        ArrayList<BMLiuyan> t_bm_liuyan = liuyanDao.search("t_bm_liuyan", String.format(" where activeId = %d order by createTime ", activeId), null);
        ArrayList<LiuYan> liuYans = new ArrayList<>();
        for(BMLiuyan l:t_bm_liuyan){
            LiuYan liuYan = new LiuYan();
            DataUtils.CopyBean(l,liuYan);
            ArrayList<BMHuifu> huifu = huifuDao.search("t_bm_huifu", String.format(" where lyId = %d order by createTime ", l.getLyId()), null);
            liuYan.setHuifus(huifu);
            liuYans.add(liuYan);
        }
        return liuYans;
    }

    public BMActive addActive(BMActive active) {
        return activeDao.insert(active);
    }

    public void deleteActive(int activeId) {
        BMActive active = new BMActive();
        active.setActiveId(activeId);
        activeDao.delete(active);
    }

    public boolean updateActive(BMActive active) {
        return activeDao.update(active);
    }

    public void lookActive(String openId, String touxiang, int activeId) {
        BMLookActive lookActive = new BMLookActive();
        if(lookActiveDao.search("t_bm_lookactive",String.format(" where openId = '%s' and activeId = %d ",openId,activeId),null).size()<=0){
            lookActive.setOpenId(openId);
            lookActive.setTouxiang(touxiang);
            lookActive.setActiveId(activeId);
            lookActiveDao.insert(lookActive);
        }
    }

    public ArrayList<BMLookActive> getLookActive(int activeId){
        return lookActiveDao.search("t_bm_lookactive",String.format(" where activeId = %d ",activeId),null);
    }

    public BMUser regeistUser(BMUser user) {
        return userDao.insert(user);
    }

    public ArrayList<BMBaoming> searchBaoming(int activeId) {
        ArrayList<BMBaoming> l = new ArrayList<>();
        Session session = baomingDao.getSession(null);
        String sql = " select * from t_bm_baoming where activeId = "+activeId+" order by joinTime asc ";
        SQLQuery query = session.createSQLQuery(sql);
        List list = query.list();
        for(int i = 0;i<list.size();i++){
            Object o[] = (Object[]) list.get(i);
            BMBaomingId baomingId = new BMBaomingId();
            BMBaoming baoming = new BMBaoming();
            baomingId.setOpenId(o[0].toString());
            baomingId.setActiveId(Integer.parseInt(o[1].toString()));
            baoming.setBaomingId(baomingId);
            baoming.setJoinTime((Date) o[4]);
            baoming.setTouxiang(o[5].toString());
            try{
                baoming.setUserName(o[2].toString());
                baoming.setPhone(o[3].toString());
            }catch (Exception e){
                System.out.println("用户名手机号为空");
            }
            l.add(baoming);
        }
        return l;
    }

    public boolean isBaoming(int activeId, String openId) {
        BMBaoming baoming = new BMBaoming();
        BMBaomingId baomingId = new BMBaomingId();
        baomingId.setActiveId(activeId);
        baomingId.setOpenId(openId);
        baoming.setBaomingId(baomingId);
        if(baomingDao.get(baoming,baomingId)==null){
            return false;
        }else {
            return true;
        }
    }

    public boolean cancelBaoming(int activeId, String openId) {
        try{
            BMBaoming baoming = new BMBaoming();
            BMBaomingId baomingId = new BMBaomingId();
            baomingId.setActiveId(activeId);
            baomingId.setOpenId(openId);
            baoming.setBaomingId(baomingId);
            baomingDao.delete(baoming);
        }catch (Exception e){
            System.out.println("没找到活动");
            return false;
        }
        return true;
    }
}
