package com.fangyuan.service;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private static Logger logger = Logger.getLogger(AuthService.class);

    public AuthService(){

    }

    /**
     * 检查token是否有效(具体的鉴权商量之后再定，现在只做模板)
     * @param timestamp
     * @param auth
     * @return
     */
    public boolean verifyToken(String timestamp, String auth, String strOpenId) {
        if(timestamp == null || timestamp.trim().isEmpty()){
            return false;
        }

        return true;
    }
}
