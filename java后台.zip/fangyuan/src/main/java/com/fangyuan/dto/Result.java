package com.fangyuan.dto;

import com.alibaba.fastjson.JSONObject;
import com.fangyuan.utils.ErrorCodeUtil;

import java.util.ArrayList;
import java.util.HashMap;

public class Result {

	/**返回错误编码*/
	private int code = 0;
	/**搜索结果总页数*/
	private int pageCount = 0;
	private int totalCount = 0;
	/**结果集*/
	private ArrayList<? extends Object> data = null;
	/**备用集合*/
	private HashMap<?,?> spare = null;
	private ArrayList<? extends Object> eight = null;
	/**错误原因*/
	private String reason = "系统正在升级...请您稍后再试！！！";

	private JSONObject jsonObject;

	public JSONObject getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(JSONObject jsonObject) {
		this.jsonObject = jsonObject;
	}

	/**
	 * 错误码，成功是200。
	 * @return 错误码。
	 */
	public int getCode() {
		return code;
	}
	
	public void setCode(int code) {
		this.code = code;
		this.reason = ErrorCodeUtil.getErrorCodeReason(code);
	}

	public ArrayList<? extends Object> getEight() {
		return eight;
	}

	public void setEight(ArrayList<? extends Object> eight) {
		this.eight = eight;
	}

	/**
	 * 结果集总页数，0无效。
	 * @return 结果集总页数。
	 */
	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	/**
	 * 结果集数组。
	 * @return 结果集数组。
	 */
	public ArrayList<? extends Object> getData() {
		return data;
	}
	
	public void setData(ArrayList<? extends Object> data) {
		this.data = data;
	}

	/**
	 * 失败原因。
	 * @return 失败原因。
	 */
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	/**
	 * 备用集合
	 * @return
	 */
	public HashMap<?, ?> getSpare() {
		return spare;
	}

	public void setSpare(HashMap<?, ?> spare) {
		this.spare = spare;
	}
	


}
