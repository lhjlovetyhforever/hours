package com.fangyuan.dto;

import com.fangyuan.entity.BMHuifu;

import java.util.ArrayList;
import java.util.Date;

public class LiuYan {
    private int lyId;
    private int activeId;
    private String openId;
    private String nickName;
    private String touxiang;
    private String content;
    private ArrayList<BMHuifu> huifus;
    private Date createTime;

    public int getLyId() {
        return lyId;
    }

    public void setLyId(int lyId) {
        this.lyId = lyId;
    }

    public int getActiveId() {
        return activeId;
    }

    public void setActiveId(int activeId) {
        this.activeId = activeId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getTouxiang() {
        return touxiang;
    }

    public void setTouxiang(String touxiang) {
        this.touxiang = touxiang;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ArrayList<BMHuifu> getHuifus() {
        return huifus;
    }

    public void setHuifus(ArrayList<BMHuifu> huifus) {
        this.huifus = huifus;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
